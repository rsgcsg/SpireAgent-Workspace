---
name: github-remote-operator
description: "Safely inspect and modify remote GitHub repositories through the GitHub connector: resolve branches and rules, create topic branches, create/update/delete text files, prepare commits, open/update draft pull requests, review diffs, inspect CI, request review, and merge only when explicitly authorized. Use when the user explicitly asks to modify GitHub, update the remote repo, commit/push a docs or config change, create a branch/PR, review or merge a PR, or align Platform/STPD remote state. Read-only questions may also use this skill for exact topology."
---

# GitHub Remote Operator

## Mission

Operate GitHub directly and safely. Default to read-only unless the user explicitly requests a remote write. An explicit request to “modify/update the remote” authorizes a normal topic-branch + pull-request workflow; it does not authorize direct writes to protected integration/release branches, force pushes, deletion, or merge.

## Preflight

Before any write:

1. Resolve repository metadata, default branch, `main`, `develop`, active branches, open PRs, and relevant rulesets/protection.
2. Read repository `AGENTS.md`, contribution/development workflow, and task-specific canonical files.
3. Identify the integration branch and exact base SHA.
4. Check for overlapping active PRs/files/contracts.
5. Choose the smallest owning repository/component.

Use `references/safe-write-protocol.md`.

## Default write workflow

```text
latest integration branch exact SHA
-> short-lived topic branch
-> small coherent remote changes
-> verify file blob SHAs before updates
-> commit(s)
-> draft PR to integration branch
-> inspect latest-head CI/status
-> update PR body with evidence/non-claims
-> stop for review unless merge was explicitly requested
```

Never force-update a ref. Never direct-push protected `main`/`develop`. Never use admin bypass as routine workflow.

## Small versus large changes

Use direct connector writes for small, reviewable text/config/doc changes with a clear file set. For multi-file implementation, generated code, builds, or local tests, prefer Codex on a topic branch, then use the connector for topology, PR metadata, review, and merge management.

Do not create a long series of tiny commits via remote file endpoints when one local/Codex change is safer and easier to test.

## File safety

- Re-fetch the current file and blob SHA immediately before `update_file` or `delete_file`.
- Do not update/delete the same path in parallel.
- Do not overwrite remote changes to make a stale branch pass.
- Keep exact base/head SHAs in the report.
- Never write secrets, credentials, raw Human data, game files, decompiled source, local artifacts, model weights, or private paths.

## Pull request policy

A PR body should include:

- repository, base branch/SHA, head branch/SHA;
- workstream and owning layer;
- problem and implemented change;
- non-goals;
- affected contracts/cross-repo pins;
- tests/evidence level;
- rollback;
- remaining non-claims.

Use draft PRs while runtime/Human gates are pending. Mark ready or merge only on explicit request and after required checks on the latest head. Use squash for ordinary topic PRs when repository policy prefers it.

## Destructive actions

Require explicit user language for:

- merge;
- closing/reopening a PR for policy reasons;
- deleting branches/files;
- changing base branches;
- force updates (normally refuse and propose a safe alternative);
- modifying rulesets/protection.

## SpireAgent adapter

For Platform and STPD, read `references/spireagent-github-adapter.md`. Platform is the upper-level foundation; STPD is a separate research repo. Normal work targets each repo's `develop`; cross-repo changes use two independent PRs and exact pins.

## Attachment-first reporting

For a large diff/review, create a Markdown change report or review attachment. Inline, provide exact refs, result, CI/evidence status, and the PR link.

## Self-update

On explicit request, update connector/tool mappings and workflow rules through `workspace-skill-maintainer` and `skill-creator`. Do not silently expand write authority.
