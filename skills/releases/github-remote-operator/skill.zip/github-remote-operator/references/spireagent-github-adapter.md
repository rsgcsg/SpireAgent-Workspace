# SpireAgent GitHub adapter

## Workspace governance relay

- Repository: `rsgcsg/SpireAgent-Workspace`.
- Purpose: small versioned Codex-facing projection of Workspace governance, pointers, shared standards, Workspace Skill releases/manifest, handoffs, and temporary relay policy.
- It is not Platform/STPD implementation or research authority.
- Normal governance work targets current `develop` through a short-lived topic branch and PR.

## Platform

- Repository: `rsgcsg/STS2-AI-PLATFORM`.
- Read `AGENTS.md` and `docs/DEVELOPMENT_WORKFLOW.md`.
- Normal base/PR target: current `develop`.
- Typical scopes: connector, host-runtime, annotator, evidence, policy-runtime, game-mod, live-ui, workbench, platform.

## STPD

- Repository: `rsgcsg/STS2-The-Perfect-Defect`.
- Read `AGENTS.md` and `docs/DEVELOPMENT_WORKFLOW.md`.
- Normal base/PR target: current `develop`.
- Keep environment, data, representation, model, training, evaluation, qualification and policy work orthogonal.

## Cross-repo

```text
Platform candidate/release exact identity
-> STPD manifest/config pin
-> STPD verification
```

Never pin STPD to floating Platform `develop`. Routine Platform/STPD work does not require Workspace as an intermediary.
