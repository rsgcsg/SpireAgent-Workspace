# SpireAgent GitHub adapter

## Platform

- Repository: `rsgcsg/STS2-AI-PLATFORM`.
- Read `AGENTS.md` and `docs/DEVELOPMENT_WORKFLOW.md`.
- Normal base/PR target: current `develop`.
- `main` may remain a frozen pre-governance baseline until a governed release; verify current docs.
- Typical scopes: connector, host-runtime, annotator, evidence, policy-runtime, game-mod, live-ui, workbench, platform.

## STPD

- Repository: `rsgcsg/STS2-The-Perfect-Defect`.
- Read `AGENTS.md` and `docs/DEVELOPMENT_WORKFLOW.md`.
- Normal base/PR target: current `develop`.
- Keep environment, data, representation, model, training, evaluation, qualification and policy work orthogonal.

## Cross-repo

```text
Platform candidate/release exact identity
-> STPD manifest/config pin
-> STPD verification
```

Never pin STPD to floating Platform `develop`.
