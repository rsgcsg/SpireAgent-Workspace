# Workspace temporary relay

## Purpose

Use a relay branch only when the ChatGPT product/file surface cannot reliably deliver an artifact, a larger connector edit is awkward, and local/Codex execution is unavailable or inappropriate.

## Naming

`relay/YYYYMMDD-<target>-<task>`

## Rules

- Temporary transport only; zero canonical implementation, research, or Skill authority.
- Never merge relay payloads into Workspace `develop`/`main`.
- Default TTL is about 3 days; normal maximum is 7 days unless explicitly justified.
- Transfer the payload to the owning destination and revalidate it there.
- Remove the relay after successful transfer/product deployment or TTL expiry.
- Relay deletion is destructive and requires explicit user authorization.
