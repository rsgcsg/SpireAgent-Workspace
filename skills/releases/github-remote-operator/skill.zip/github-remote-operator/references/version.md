Version: 1.2.1
Updated: 2026-08-28
Scope: canonical GitHub connector read/write/PR workflow, exact-ref preflight, Platform/STPD adapter, and Workspace governance writes through topic branches.
