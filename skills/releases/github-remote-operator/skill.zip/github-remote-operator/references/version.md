Version: 1.3.0
Updated: 2026-08-28
Scope: current SpireAgent Workspace/Platform/STPD repository model, latest-head PR discipline, explicit destructive-action authorization, governed temporary relay transport, and post-product Workspace Skill release reconciliation.
