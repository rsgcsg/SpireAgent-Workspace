# Safe GitHub write protocol

## Read phase

- Resolve repo and branch topology.
- Resolve protection/rulesets and required checks.
- Read contribution/agent instructions.
- Pin integration base SHA.
- Inspect overlapping PRs and exact target files.

## Write phase

- Create a topic branch from exact base.
- Use create/update/delete file actions only for small text changes.
- For updates/deletes, use the current blob SHA.
- Keep sequential writes to the same path.
- Open a draft PR.
- Inspect CI/status on the latest head SHA.
- Update PR metadata after additional commits.

## Merge phase

Only when explicitly requested:

- verify PR is mergeable;
- verify required checks on latest head;
- inspect unresolved review threads/conversations;
- verify base has not drifted materially;
- use repository-preferred merge method;
- report merge SHA and post-merge branch state.

Do not confuse a connector API success with CI, runtime, or release evidence.
