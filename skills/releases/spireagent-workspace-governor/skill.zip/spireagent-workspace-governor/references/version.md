Version: 1.1.1
Updated: 2026-08-28
Scope: central SpireAgent workspace governance around rsgcsg/SpireAgent-Workspace with exact Platform/STPD authority separation and Skill source/version routing.
