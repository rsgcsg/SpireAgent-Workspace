Version: 1.6.0
Updated: 2026-08-28
Scope: small Workspace-to-Codex relay model plus bounded web-research routing for current external facts and mature public tooling, with durable curation instead of repeated broad browsing.
