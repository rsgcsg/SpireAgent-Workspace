Version: 1.2.0
Updated: 2026-08-28
Scope: central SpireAgent workspace governance with remote-first GitHub authority, exact Platform/STPD separation, and stable Skill shell semantics.
