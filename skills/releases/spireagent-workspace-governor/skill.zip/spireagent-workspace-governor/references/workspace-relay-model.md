# Workspace relay model

Use four planes with explicit promotion rules.

| Plane | Typical contents | Lifetime | Authority |
|---|---|---|---|
| Chat/session scratch | drafts, generated reports, temporary downloads, `/mnt/data` artifacts | current execution/session | none unless separately promoted |
| ChatGPT Workspace knowledge | Project/Library/Work files, reusable references, handoffs, larger collaboration artifacts | persistent when product surface supports it | collaboration/reference only |
| `SpireAgent-Workspace` GitHub | selected web-Workspace projection for Codex, router, shared standards, source-of-truth map, current pointers, Workspace Skill manifest/releases, handoffs, temporary relay rules | durable/versioned | workspace governance/relay only |
| Platform/STPD owning repos | source, tests, runtime/research evidence, canonical project docs, repo-owned agent/Skill governance | durable/versioned | implementation/runtime/research authority |

## Primary purpose of `SpireAgent-Workspace`

Keep it small. Its most important role is to expose reviewed web-Workspace conclusions and cross-project context in a versioned Git form that Codex can read when it cannot see the original ChatGPT Workspace discussion. It is also the durable home of Workspace-level Skill governance and cross-project policy.

Do not mirror the Library, chats, Platform source, STPD source, raw evidence, datasets, or model artifacts.

## Read path

For routine single-repo work, read the owning repo directly. Use Workspace Git only when the task needs cross-project routing, shared Workspace decisions/standards, Skill governance, a web-Workspace handoff/reference, or temporary relay context.

When Workspace context is used, validate mutable implementation/research claims against the exact owning repo.

## Promotion path

`TEMP -> reviewed Workspace knowledge -> small durable Git pointer/summary` only when useful. Implementation/evidence content belongs in the owning repo. Large reusable references may remain in ChatGPT Library/connected storage with a durable pointer when the product/tool surface exposes them.

## Product/API boundary

A visible ChatGPT Library UI does not imply that the active agent has a generic Library CRUD API. Inventory/create/update/move/delete Library content only when the actual tool surface exposes those operations. Otherwise generate/attach the artifact and report the user-side promotion step.

## Reconciliation

On calibration/update flows, compare installed Workspace Skill deployments with the Workspace manifest and compare `workspace/CURRENT.md` with live refs. Treat mismatches as normal drift to close, not as new sources of truth.
