# Routing table

Use the most specific route.

| Intent | Primary skill | Governance repo role | Project repo role |
|---|---|---|---|
| Current status / architecture / blocker | spireagent-explainer | router + current pointers | authoritative facts |
| Codex prompt / task | spireagent-codex-prompt-writer | model policy + attachments | implementation target |
| Conversation digest / ADR / handoff seed | spireagent-conversation-organizer | durable index | verify implementation claims |
| New chat / context overflow | spireagent-context-handoff | HANDOFF pointer + dated file | refresh exact refs |
| Knowledge/library cleanup | workspace-knowledge-librarian | primary store/index | linked authorities |
| Remote GitHub write | github-remote-operator | governance target when workspace-wide | direct target when project-owned |
| Skill update | workspace-skill-maintainer + skill-creator | source + manifest | read current project facts before release |

## Ambiguous task rule

If a task mixes status + prompt writing, use the prompt writer after enough Explainer-style grounding. If it mixes chat history + current repo status, organize first, then verify exact claims. If it asks to modify the remote, the write path always belongs to github-remote-operator even when another skill supplies the content.
