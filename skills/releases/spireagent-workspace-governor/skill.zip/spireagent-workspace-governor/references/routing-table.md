# Routing table

Use the most specific route.

| Intent | Primary skill | Workspace Git role | Project repo role |
|---|---|---|---|
| Current status / architecture / blocker | spireagent-explainer | optional router/pointer | authoritative facts |
| Codex prompt / task | spireagent-codex-prompt-writer | use only for cross-project/web-Workspace context | implementation target |
| Conversation digest / ADR / handoff seed | spireagent-conversation-organizer | durable reviewed projection when useful | verify project claims |
| New chat / context overflow | spireagent-context-handoff | optional durable handoff pointer | refresh exact refs |
| ChatGPT Library / Project cleanup | workspace-knowledge-librarian | small durable index/pointers | linked authorities |
| Remote GitHub write | github-remote-operator | target only for workspace-owned governance/relay | direct target for project-owned work |
| Workspace Skill update | workspace-skill-maintainer + skill-creator | source/release/manifest authority | none unless project facts must be read |
| External current facts / mature tooling research | governor + task-specific Skill | curate durable conclusions/pointers only | project repo remains authority for implementation choices |
| Platform/STPD repo Skill update | owning repo workflow + skill-creator | optional pointer only | repo owns source/version/evals |

## Ambiguous task rule

Routine single-repository development goes straight to the owning repo. Add Workspace context only when it materially contributes web-Workspace decisions, shared standards, cross-repo routing, Skill governance, or handoff material. Remote writes always use `github-remote-operator` after explicit authorization.
