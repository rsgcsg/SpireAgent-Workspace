# Governance model

`SpireAgent-Workspace` is a small durable bridge, not a third main project. It is the versioned Codex-facing projection of selected ChatGPT web Workspace knowledge and the durable home for cross-project governance.

It may contain:
- Workspace-level Skill source/release pointers and version manifests;
- shared Project instructions and cross-project standards;
- workspace routing/current/handoff/decision pointers;
- knowledge maps and links to Library/Project artifacts;
- templates and Codex/reference attachments worth exposing to agents;
- reviewed cross-repository coordination notes;
- short-lived relay policy and metadata.

It must not become:
- a copy of Platform/STPD source;
- the owner of Platform/STPD repo Skills;
- a competing runtime/evidence/research authority;
- a raw transcript/Library mirror;
- a secret/model-weight/game-file store.

Routine Platform/STPD development should remain possible without Workspace. Use Workspace as optional context enrichment and cross-project transport.
