# Governance model

`SpireAgent-Workspace` is a control-plane repository. It owns the map, not the territory.

It may contain:
- Skill source and version manifests;
- Shared Project instructions;
- workspace routing/current/handoff/decision pointers;
- templates and long Codex/reference attachments;
- reviewed cross-repository coordination notes.

It must not become:
- a copy of Platform/STPD source;
- a competing runtime/evidence authority;
- a raw transcript/log dump;
- a secret/model-weight/game-file store.

For any current claim, refresh the owning repo. For any workspace continuity question, start from the governance repo.
