---
name: spireagent-workspace-governor
description: "Govern and route work across the entire SpireAgent / Slay the Spire AI workspace. Use for workspace-wide coordination, deciding which SpireAgent skill/repository owns a task, aligning ChatGPT shared-project context with GitHub, checking Skill versions, managing the SpireAgent-Workspace governance repository, starting a new chat from a handoff, or any SpireAgent request where project context/routing itself matters. Treat rsgcsg/SpireAgent-Workspace as the governance router while Platform/STPD remain their own code/runtime authorities."
---

# SpireAgent Workspace Governor

## Mission

Act as the thin control plane for the SpireAgent workspace. Keep routing, Skills, handoffs, shared-project instructions, knowledge pointers, and cross-repository coordination coherent without becoming a second source of game/runtime truth. Respond in Chinese by default.

## Governance repository

Use `rsgcsg/SpireAgent-Workspace` as the workspace-governance source of truth when accessible. Read in this order:

1. `WORKSPACE_ROUTER.md`;
2. `workspace/CURRENT.md`;
3. `workspace/SOURCE_OF_TRUTH.md`;
4. `skills/SKILL_SUITE_MANIFEST.json`;
5. `workspace/HANDOFF.md` when continuity matters;
6. only the task-specific governance/reference files.

The governance repo owns routing and coordination, not Platform/STPD implementation truth. Always verify current code/runtime claims in the owning repository.

## Repository authority

```text
rsgcsg/SpireAgent-Workspace
  -> workspace governance, Skill sources/manifest, handoffs, shared instructions, references, cross-repo pointers

rsgcsg/STS2-AI-PLATFORM
  -> Platform Foundation code/contracts/runtime/evidence

rsgcsg/STS2-The-Perfect-Defect
  -> STPD research projection/data/model/training/evaluation
```

Never let Workspace documents override an exact Platform/STPD ref. A `workspace/CURRENT.md` entry is a dated pointer/snapshot and must be refreshed for current-state claims.

## Route tasks

Use the most specific skill:

- current state, architecture, evidence, blocker, repo/history alignment -> `spireagent-explainer`;
- Codex task/prompt/review/reference packet -> `spireagent-codex-prompt-writer`;
- chat/meeting/PR/run discussion organization -> `spireagent-conversation-organizer`;
- context overflow/new chat/team handoff -> `spireagent-context-handoff`;
- knowledge map/library/source-of-truth cleanup -> `workspace-knowledge-librarian`;
- explicit GitHub writes/branches/PR/merge -> `github-remote-operator`;
- Skill update/package/version/rollout -> `workspace-skill-maintainer` + built-in `skill-creator`.

Read `references/routing-table.md` for ambiguous cases.

## New-chat bootstrap

If a conversation is new, truncated, or missing project context:

1. read the governance router/current/handoff;
2. refresh relevant Platform/STPD remote refs;
3. state any mismatch between handoff and remote;
4. invoke the most specific skill;
5. do not reconstruct project history from memory when durable sources exist.

## Workspace updates

When the user explicitly requests a governance change, use `github-remote-operator` to modify `rsgcsg/SpireAgent-Workspace` through a topic branch and PR unless the repository policy explicitly allows a simpler path. Update the router, knowledge map, handoff/current pointers, and Skill manifest together when their relationships change.

## Attachment-first rule

Do not paste long architecture/history/Codex references into chat. Put durable long content in an attachment and, when explicitly requested, store or index it in the governance repo. Keep chat output to the decision, exact refs, and links.

## Skill currency

Treat installed Skills as deployments. Compare them with `skills/SKILL_SUITE_MANIFEST.json` when version drift matters. Never silently self-update. On explicit request, use `workspace-skill-maintainer` + `skill-creator`, validate/package each Skill separately, then update the governance manifest.

## Remote-first current truth

For current-state work, load `references/remote-authority.md` and refresh GitHub before substantive project claims. Keep mutable project status out of this Skill; the Skill should change mainly when triggers, routing, authority boundaries, or tool workflow change.

## Guardrail

The workspace repo must not contain secrets, raw Human data, proprietary STS2 files/decompiled source, model weights, local runtime artifacts, or copied code/runtime authority from Platform/STPD. Store pointers, reviewed summaries, templates, Skill source, and governance only.
