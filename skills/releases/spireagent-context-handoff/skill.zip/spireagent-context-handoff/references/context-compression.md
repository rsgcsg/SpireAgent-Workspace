# Context compression rules

- Prefer exact current state over chronology.
- Preserve the last accepted decision and one sentence explaining why important alternatives were rejected.
- Keep historical/runtime/scientific evidence scoped to exact identities.
- Separate Workspace governance, Platform, STPD, and unrelated workstreams.
- Point to existing Workspace/Library references or durable Git references instead of copying large material into the handoff.
- Include only the latest usable prompt; reference older prompts only when still relevant.
- Label time-sensitive external knowledge with freshness/re-verification needs.
- State what the new chat must re-verify instead of claiming permanent freshness.
- Target roughly 1,500-4,000 words for a complex handoff; split into handoff plus evidence/reference appendix if larger.
