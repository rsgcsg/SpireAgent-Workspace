# Context compression rules

- Prefer exact current state over chronological narration.
- Preserve the last accepted decision and one sentence explaining why earlier alternatives were rejected.
- Keep historical evidence immutable and scoped to exact identities.
- Separate active Platform, STPD, and unrelated workstreams.
- Include only the latest usable Codex prompt; link older references if still relevant.
- State what the new chat must re-verify rather than claiming permanent freshness.
- Target 1,500-4,000 words for a complex handoff; split into a handoff plus evidence appendix if larger.
