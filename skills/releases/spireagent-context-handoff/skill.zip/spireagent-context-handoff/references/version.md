Version: 1.1.1
Updated: 2026-08-28
Scope: current SpireAgent workspace new-chat handoff with exact Workspace/Platform/STPD refs and evidence boundaries.
