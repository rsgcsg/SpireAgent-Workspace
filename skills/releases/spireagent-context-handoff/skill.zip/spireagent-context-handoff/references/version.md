Version: 1.2.0
Updated: 2026-08-28
Scope: remote-first new-chat handoff with exact Workspace/Platform/STPD refs, evidence boundaries, and stable workflow-shell semantics.
