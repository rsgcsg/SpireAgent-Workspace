Version: 1.4.0
Updated: 2026-08-28
Scope: lean handoff with Workspace/Library/Git reference pointers, exact owning-repo refresh, explicit external-knowledge freshness, stronger compression, and unchanged local read-only privacy boundary.
