# Handoff template

```markdown
# SpireAgent Context Handoff

## 1. Scope and source quality
- Conversation sources:
- Uploaded files:
- GitHub inspection time:
- External-reference freshness:
- Known limitations:

## 2. System hierarchy and authority

## 3. Exact current repository topology
| Repo | Main | Develop | Active branch/PR | Status |

## 4. Current main objective

## 5. Current implementation and evidence
| Capability | Source/test | Build/install/load | Human/runtime | Scientific/qualification | Non-claims |

## 6. Exact artifacts and sessions

## 7. Accepted decisions

## 8. Rejected/superseded approaches

## 9. Active workstreams and owners

## 10. Current blockers and risks

## 11. Workspace/Library/Git reference pointers
| Reference | Plane | Role | Freshness | Authority |

## 12. Immediate next task
- Goal:
- Owning layer:
- Branch/PR:
- Checks:
- Stop/Human gate:

## 13. Attachments and canonical files to read

## 14. New-chat bootstrap prompt
```
