# Remote-first SpireAgent authority

Treat this installed Skill as a stable workflow/trigger bundle, not as the source of changing project status.

When a request depends on current SpireAgent state:

1. Use the connected GitHub connector first.
2. Read `rsgcsg/SpireAgent-Workspace` at current `develop` (or an exact governance ref supplied by the user) for `WORKSPACE_ROUTER.md`, `workspace/CURRENT.md`, `workspace/SOURCE_OF_TRUTH.md`, and `skills/SKILL_SUITE_MANIFEST.json` as needed.
3. Resolve the owning Platform/STPD branch, PR, and exact SHA from GitHub before making current implementation/evidence claims.
4. Prefer exact owning-repository truth over packaged prose, conversation memory, Workspace snapshots, or historical phase names.
5. If GitHub is unavailable, say current verification is unavailable and use only explicitly dated fallback material.

While reading the manifest, compare this installed Skill's `references/version.md` with the manifest version. A newer manifest version is an update signal, not permission to self-modify. If the current workflow remains compatible, continue the user task using remote authority and mention `SKILL_UPDATE_AVAILABLE` briefly. If routing/authority/tool semantics changed incompatibly, route to `workspace-skill-maintainer` + `skill-creator` before relying on the stale workflow.
