# Skill routing after handoff

- Current status, architecture, blocker, repo alignment: `spireagent-explainer`.
- Codex task/prompt/PR scope: `spireagent-codex-prompt-writer`.
- Conversation digest/ADR/action items: `spireagent-conversation-organizer`.
- Explicit GitHub remote write: `github-remote-operator`.
- Library/file/document-map management: `workspace-knowledge-librarian`.
- Skill updates/releases: `workspace-skill-maintainer` plus `skill-creator`.
