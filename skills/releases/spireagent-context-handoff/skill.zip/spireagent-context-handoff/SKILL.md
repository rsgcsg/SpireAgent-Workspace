---
name: spireagent-context-handoff
description: "Create a precise new-chat handoff when a SpireAgent, STS2 AI Platform, STPD, Connector, Annotator, Full-Run, Policy Runtime, or Slay the Spire AI conversation becomes too long, loses context, contains skipped messages, or must continue in a fresh chat. Use for requests such as 上下文爆了, 新对话继续, 仔细对齐历史, 换窗口, 接着上个对话, generate a handoff, or package all current repo/conversation/evidence state for another person or agent."
---

# SpireAgent Context Handoff

## Mission

Move a saturated project conversation into a fresh chat without losing current repository truth, accepted decisions, evidence boundaries, or the immediate engineering task. Respond in Chinese by default.

The main deliverable is always a Markdown attachment. Do not paste a giant handoff inline.

## Trigger signs

Use this workflow when any of these appear:

- the user says the context/window is full, confused, or needs a new chat;
- many messages are skipped or summarized;
- repeated requests ask to re-align the same history;
- more than two active workstreams/repositories are mixed together;
- current branches/artifacts/evidence are being forgotten;
- a new person/agent needs to take over.

## Workflow

1. Collect visible conversation context, shared-project excerpts, uploaded histories, and existing handoffs.
2. Resolve current Platform and STPD refs/PRs/SHAs from GitHub.
3. Read canonical status/roadmap/coverage/evidence files relevant to the active work.
4. Classify conversation decisions versus repo facts and runtime evidence.
5. Create `SPIREAGENT_CONTEXT_HANDOFF_<date>.md` using `references/handoff-template.md`.
6. Include a short new-chat bootstrap prompt that explicitly invokes this skill first, then routes to explainer/prompt-writer/GitHub operator as needed.
7. Inline, provide only 5-10 key facts, the attachment link, and the exact sentence to paste into the new chat.

## Compression rules

Preserve:

- project hierarchy and authority;
- exact repos/branches/PRs/SHAs;
- current main objective and phase;
- current artifact/session/runtime identities;
- proved/source-test/build/load/Human/non-claim boundaries;
- accepted decisions and reasons;
- rejected approaches that are likely to recur;
- active workstreams and branch ownership;
- immediate next task, stop gate, and Human test path;
- relevant attachments/prompts.

Drop:

- repetitive back-and-forth;
- obsolete prompts superseded by later versions;
- low-level tool chatter;
- unsupported assistant speculation;
- raw logs that already have a reviewed closeout.

Use `references/context-compression.md`.

## New-chat bootstrap

Default sentence:

```text
使用 spireagent-context-handoff，先完整读取附件并重新核对当前远端，再根据任务调用 spireagent-explainer、spireagent-codex-prompt-writer 或 github-remote-operator。不要从旧默认分支或聊天摘要猜当前状态。
```

## Attachment and privacy

The handoff must be a reusable attachment, not a chat-only answer. Redact secrets, private paths, raw Human data, model weights, and sensitive personal information. Link large supporting files rather than embedding them.

## Remote-first current truth

For current-state work, load `references/remote-authority.md` and refresh GitHub before substantive project claims. Keep mutable project status out of this Skill; the Skill should change mainly when triggers, routing, authority boundaries, or tool workflow change.

## Self-update

When handoffs repeatedly miss a field or project structure changes, use `workspace-skill-maintainer` and `skill-creator` to update the template/triggers, validate, and return a full `skill.zip`.
