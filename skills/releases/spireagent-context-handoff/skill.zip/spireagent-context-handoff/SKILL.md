---
name: spireagent-context-handoff
description: "Create a precise local, user-controlled Markdown handoff for continuing a SpireAgent, STS2 AI Platform, or STPD conversation in a fresh chat when context becomes long, truncated, or hard to recover. Use for requests such as context overflow, new-chat continuation, window switching, or reusable handoff creation. Preserve exact refs, accepted decisions, evidence boundaries, blockers, Workspace/Library reference pointers, and the immediate task while excluding secrets and avoiding automatic sharing or repository writes."
---

# SpireAgent Context Handoff

## Mission

Create a compact handoff so a fresh chat can resume without losing current repository truth, accepted decisions, evidence boundaries, curated knowledge pointers, or the immediate engineering task. Respond in Chinese by default. The Skill is read-only and user-controlled.

## System model

Preserve this distinction:

- ChatGPT Workspace/Library: working knowledge, larger reusable files, references, and collaboration when accessible.
- `rsgcsg/SpireAgent-Workspace`: small durable Codex-facing relay for governance, pointers, shared standards, handoffs, and Workspace Skills.
- `rsgcsg/STS2-AI-PLATFORM`: implementation/contracts/runtime/evidence authority.
- `rsgcsg/STS2-The-Perfect-Defect`: research/data/model/training/evaluation authority.

Workspace material is context/pointer/cache unless explicitly canonical for Workspace governance. Exact owning-repo evidence overrides handoff snapshots.

## Workflow

1. Collect only the conversation context, uploaded histories, and existing handoffs available in the current user-controlled session.
2. When current repository state matters, resolve current Workspace/Platform/STPD refs and PRs through GitHub read access.
3. Read only canonical status/roadmap/coverage/evidence files needed for the active task.
4. Separate conversation decisions from repository facts and source/test/build/load/Human/scientific evidence.
5. Prefer pointers to existing Workspace/Library references and durable Git pointers instead of copying large source material.
6. Create `SPIREAGENT_CONTEXT_HANDOFF_<date>.md` using `references/handoff-template.md`.
7. Include one concise new-chat bootstrap prompt.
8. Return the local artifact and summary. Do not transmit it to another user, agent, service, workspace, or repository.

## Compression

Use `references/context-compression.md`.

Preserve:
- project hierarchy and authority;
- exact repos/branches/PRs/SHAs;
- current objective and phase;
- exact artifacts/sessions/runtime identities when relevant;
- evidence/non-claim boundaries;
- accepted decisions and why;
- rejected approaches likely to recur;
- blockers/risks;
- immediate next task and stop/Human gate;
- relevant Workspace/Library/Git reference pointers;
- latest useful prompt/attachment.

Drop repetitive discussion, superseded prompts, low-level tool chatter, unsupported speculation, and raw logs already captured by a reviewed closeout/reference.

## External-knowledge freshness

If a handoff contains current external product/API/tooling knowledge, label whether it came from a curated reference and when the next chat should re-verify it. Do not freeze time-sensitive web findings as permanent project truth.

## New-chat bootstrap

Default:

```text
Use spireagent-context-handoff to read this handoff first, then refresh the relevant GitHub refs and invoke the most specific SpireAgent Skill for the task. Current repository/runtime evidence overrides this handoff snapshot; reuse curated Workspace references when still fresh and perform bounded external research only for a real current knowledge gap.
```

## Privacy and transfer boundary

Keep the handoff local to the user unless they explicitly choose to share it. Exclude credentials, secrets, private paths, raw Human data, model weights, sensitive personal information, and unnecessary access-controlled content. This Skill never publishes, emails, uploads, invites, or modifies repositories.

## Self-update

On explicit workflow-update requests, use `workspace-skill-maintainer` plus built-in `skill-creator`. The working Project chat prepares the exact change; the reliable default product path is `Plugins -> Skills -> Create -> Create with chat`, where a dedicated Skill Chat updates the existing Skill and completes native save/install. Do not create a duplicate.
