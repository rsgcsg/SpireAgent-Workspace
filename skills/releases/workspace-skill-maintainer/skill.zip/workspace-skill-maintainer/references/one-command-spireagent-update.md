# One-command SpireAgent Skill update

When the user says `更新 SpireAgent Skills` or `一键更新 SpireAgent Skills`:

1. Use the GitHub connector to read `rsgcsg/SpireAgent-Workspace` `develop` and `skills/SKILL_SUITE_MANIFEST.json`.
2. Compare manifest versions with installed Skill `references/version.md` values when available.
3. If no deployment or workflow drift exists, return `NO_SKILL_UPDATE`.
4. If only deployment is stale, retrieve the canonical `source_archive_path`, verify the manifest SHA-256 and Skill identity/version, and return only the changed `skill.zip` packages. Do not rebuild identical Skills.
5. If workflow/trigger/authority/tool behavior must change, use `skill-creator`, update the full affected Skill source, validate and package it, bump the manifest, and create a branch named `chore/workspace/skill-update-<date>-<slug>` targeting Workspace `develop`.
6. Keep a Skill-update PR limited to `skills/releases/**/skill.zip`, `skills/SKILL_SUITE_MANIFEST.json`, `skills/README.md`, and `workspace/SKILL_ROLLOUT.md` when automatic merge is desired. The Skill Governance matrix must pass; eligible same-repository Skill-update PRs then auto-merge to `develop`.
7. Any change to routing authority, CI/workflow code, validators, repository policy, or other governance files is not eligible for automatic merge and requires a normal reviewed governance PR.
8. After repository merge, return only the Skills whose deployment packages changed, in recommended upload order. Installation/publishing remains a separate supported-product action unless a real deployment API is available and used.

This workflow deliberately keeps Skills stable. Mutable project truth belongs in the remote Workspace/Platform/STPD repositories, not in frequent Skill rewrites.
