# Workspace rollout

Recommended sequence:

1. Enable Skills/upload/share/publish/install permissions for the intended roles.
2. Upload packages and review scanner results.
3. Share project-specific skills with the SpireAgent team; publish generic workspace skills more broadly if appropriate.
4. Install default project skills for team members when available.
5. Add the skills to a SpireAgent Workspace Agent if Workspace Agents are enabled.
6. Add only the required project files and GitHub connector; use connector action constraints for narrowly scoped writes.
7. Test ChatGPT web/desktop and Codex separately.
8. Review usage/invocation metadata and ownership monthly or after a major project phase change.

Keep a source-controlled or Library-hosted copy of every released skill source and rollback ZIP.
