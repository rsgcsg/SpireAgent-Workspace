# Suite manifest

Track:

- skill name;
- version;
- project-specific or workspace-generic;
- owner and backup owner;
- trigger summary;
- dependencies/connectors;
- ChatGPT installed version;
- Codex installed version;
- last real-task test;
- known overlap/conflicts;
- rollback package;
- next audit trigger.
