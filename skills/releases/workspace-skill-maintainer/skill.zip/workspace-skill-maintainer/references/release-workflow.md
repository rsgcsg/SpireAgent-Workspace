# Skill release workflow

1. Record current version and source.
2. Collect concrete usage examples and update requirements.
3. Edit full skill source, not a patch-only artifact.
4. Validate frontmatter, description, metadata, references, scripts, and package size.
5. Run scripts or representative tests.
6. Package one skill per `skill.zip`.
7. Record version, date, change summary, compatibility, and rollback package.
8. Upload to a test user or private share first.
9. Test real invocations in ChatGPT and Codex separately.
10. Publish/install to the workspace after review.
