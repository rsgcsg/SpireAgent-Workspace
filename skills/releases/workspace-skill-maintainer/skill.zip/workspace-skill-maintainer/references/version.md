Version: 1.9.1
Updated: 2026-08-28
Scope: default dedicated Plugins > Skills > Create > Create with chat prompt handoff, with generic Project-chat Skill-card rendering explicitly classified as opportunistic/partial after a 1-of-8 render test.
