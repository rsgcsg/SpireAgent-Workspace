Version: 1.2.0
Updated: 2026-08-28
Scope: canonical Skill suite audit, stable remote-first SpireAgent Skill policy, one-command update flow, deterministic packaging, rollout, and governed auto-merge.
