Version: 1.1.1
Updated: 2026-08-28
Scope: canonical Skill suite audit, source authority, deterministic validation, per-Skill packaging, rollout, and explicit self-update governance.
