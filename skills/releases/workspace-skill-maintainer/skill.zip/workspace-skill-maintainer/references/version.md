Version: 1.2.1
Updated: 2026-08-28
Scope: canonical Skill suite audit, stable remote-first SpireAgent Skill policy, one-command update flow, deterministic packaging, governed auto-merge, and mandatory verified clickable top-level sandbox download delivery.
