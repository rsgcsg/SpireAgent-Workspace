---
name: workspace-skill-maintainer
description: "Audit, update, validate, package, version, and prepare explicit rollout of workspace Skills from real usage and repository changes. Use when the user asks to update, improve, troubleshoot, package, deploy, or reconcile Skills, including 一键更新 SpireAgent Skills. Always use with built-in skill-creator. Prefer the dedicated ChatGPT Plugins / Skills / Create / Create with chat workflow for Skill creation and updates: prepare the exact update prompt in the working conversation, then have the user paste it into that native Skill-chat surface so `skill-creator` can update the existing Skill. Fall back to other native Skill/file surfaces or an explicitly authorized short-lived Workspace Git relay only when the dedicated Skill-chat path is unavailable or fails. Never claim product delivery, installation, or GitHub writes without observed confirmation."
---

# Workspace Skill Maintainer

## Mission

Maintain a small, reliable Skill suite as versioned operational infrastructure. Complement, and never replace, built-in `skill-creator`.

Audit, prepare, validate, package, and report. Do not silently self-modify, install/publish Skills, change workspace permissions, or perform GitHub writes without explicit authorization.

## Mandatory workflow

1. Invoke/read `skill-creator`.
2. Gather concrete recent usage examples: successful tasks, failures, repeated clarifications, missed triggers, stale assumptions, and actual product results.
3. Inspect every affected Skill's `SKILL.md`, metadata, references, scripts, and version notes.
4. Separate project-specific knowledge from workspace-generic workflows.
5. Keep `SKILL.md` concise; move detailed policy to one-level-deep references.
6. Update descriptions so triggering is specific and authority is explicit.
7. Minimize implicit authority: read-only Skills may auto-trigger; write/publish/install/self-modification behavior must require explicit user action and route to the owning tool/Skill.
8. Run deterministic validation and representative script tests.
9. Run the product feasibility gate described below. Local validation is necessary but not sufficient.
10. Package each Skill separately as a complete `skill.zip`; never combine multiple Skill entrypoints into one Skill upload. Keep the ZIP as the canonical validation/rollback artifact even when native product delivery is used.
11. Record version, canonical package SHA-256, product state, delivery state, and rollout notes.
12. Run reconciliation closeout: compare installed deployment/product state with the remote manifest and compare `workspace/CURRENT.md` with live GitHub refs when relevant.
13. When Skill/product behavior may have changed, check current official OpenAI Help/Developer documentation before choosing the workflow. Product documentation can prove a capability exists; it does not prove every chat surface exposes the same renderer/action.
14. Select the strongest actually supported product delivery surface. Treat generic Project-chat card rendering as opportunistic, not the suite default: a 2026-08-28 eight-Skill render test produced only one visible Governor card. **Default to the dedicated native Skill-chat handoff:** prepare one exact prompt that tells ChatGPT to modify the named existing Skill, preserve identity, use the current installed Skill as baseline, apply the requested changes, invoke `skill-creator`, and finish through the native Skill update/install flow. Tell the user to open `Plugins > Skills > Create > Create with chat` and paste that prompt. This is the default update path unless the product exposes a stronger direct update action in the current surface.
15. Treat the working conversation as the preparation/audit surface and the dedicated Skill-chat conversation as the product deployment surface. Do not require the user to manually reconstruct requirements; provide the complete prompt. After the user reports the native product result, reconcile product state and GitHub manifest.
16. If the dedicated Skill-chat path is unavailable or fails, prefer a product-native generated-file/file-card or Library retrieval path for the complete validated ZIP. Treat `sandbox:/mnt/data/...` as best-effort compatibility only, never as `DELIVERY=PASS` by itself.
17. If the current chat cannot expose a native Skill action or reliable native file delivery, an explicitly authorized short-lived `SpireAgent-Workspace` relay branch may provide a normal GitHub download path. Relay content has zero Skill-release authority; never merge delivery blobs into Workspace integration branches. Remove the relay after product acceptance/save is confirmed or at TTL expiry.
18. For multiple changed Skills, prepare the complete changed set first, but do not rely on generic Project-chat multi-card rendering. Generate one complete Skill Chat Prompt per changed Skill by default. Use a combined native batch flow only after that dedicated product surface has been explicitly verified to update several existing Skills safely.
19. Never claim a card, file, save, install, product acceptance, relay publication, or cleanup occurred unless the relevant product/GitHub result is actually observed.


## Product feasibility is authoritative

Do not equate any of these with ChatGPT deployment success:

- validator PASS;
- package creation success;
- ZIP integrity;
- GitHub CI green;
- manifest hash match;
- an assistant statement that a card or link should appear;
- a `sandbox:` path existing in the execution environment.

Track product acceptance/save, deployment, delivery, and real invocation separately. If the UI reports `无效技能`, `Invalid skill`, `Needs Review`, or `Blocked`, record the exact result and do not claim the release is deployable.

## One-command SpireAgent update

Treat `更新 SpireAgent Skills` and `一键更新 SpireAgent Skills` as explicit authorization to audit and prepare the governed update.

- Prefer reusing an exact canonical package when only deployment is stale.
- Rebuild only Skills whose workflow/trigger/authority/tool instructions changed.
- Repository writes route to `github-remote-operator`; a delivery relay is allowed only when the user has authorized that fallback.
- Default to a generated native-update prompt for `Plugins > Skills > Create > Create with chat`. The observed partial renderer result (one visible Governor card from an eight-Skill test) is evidence that a generic Project chat may render some Skill cards, not that it can reliably deliver a suite. The prompt must name the existing Skill, say not to create a duplicate, use the current installed version as baseline, apply the exact validated changes, invoke `skill-creator`, and finish through the native update/install surface.
- When several Skills change, prepare one prompt per Skill by default; a combined prompt is acceptable only if the dedicated Skill-chat surface demonstrably supports updating multiple existing Skills without ambiguity.
- Never call an update complete until product acceptance/save state and delivery are confirmed or explicitly marked pending/blocked.
- After product confirmation, reconcile canonical release/manifest state and any relevant snapshot drift.

## Workspace rollout

Prefer the shortest actually supported route:

1. dedicated `Plugins > Skills > Create > Create with chat` prompt handoff for native create/modify/install;
2. a stronger direct native Skill update action/API when actually exposed;
3. native generated-file attachment/file card or Library retrieval;
4. explicitly authorized short-lived Workspace Git relay with ordinary GitHub download;
5. `sandbox:` only as best-effort compatibility.


## Suite design

Prefer project-specific Skills for domain workflows, generic Skills for workspace governance/knowledge/tooling, attachment-first references, and remote-first mutable project truth. Avoid giant omniscient Skills, silent self-modification, implicit remote writes, automatic data export, or many nearly identical micro-Skills.

## Output

Return:

- the shortest actionable native update/install surface when actually available;
- otherwise the strongest verified file/relay transport actually available, without falsely promising cards or links;
- manifest/version/hash summary;
- a feasibility matrix with `LOCAL_VALIDATION`, `PRODUCT_SCAN`, `DEPLOYMENT`, `DELIVERY`, and `REAL_INVOCATION`;
- changed behavior, migration notes, limitations, and exact next validation action.

## Safety

Review uploaded/external Skills before installation. Do not package secrets, private data, credentials, raw runtime data, proprietary files, or untrusted executable assets. Keep each package below the platform upload limit. Never broaden connector, repository, sharing, installation, or self-update authority merely to make a product scan pass.
