---
name: workspace-skill-maintainer
description: "Audit, create, update, validate, package, version, publish, and govern a workspace Skill suite based on real conversations, repository changes, invocation gaps, and team workflows. Use when the user asks to update/improve/package Skills, align Skills with a project, add self-update behavior, review trigger overlap, publish Skills to a Business workspace, or maintain ChatGPT/Codex skill parity. Always use together with the built-in skill-creator workflow."
---

# Workspace Skill Maintainer

## Mission

Maintain a small, reliable Skill suite as versioned operational infrastructure. This skill complements, and never replaces, `skill-creator`.

## Mandatory workflow

1. Invoke/read `skill-creator`.
2. Gather concrete recent usage examples: successful tasks, failures, repeated clarifications, missed auto-triggers, and stale project assumptions.
3. Inspect every affected skill's `SKILL.md`, metadata, references, scripts, and version notes.
4. Separate project-specific knowledge from workspace-generic workflows.
5. Keep `SKILL.md` concise; move large details to one-level-deep references.
6. Update descriptions so triggering is specific and overlap is intentional.
7. Add or update self-update/version notes without granting silent self-modification.
8. Run deterministic validation and representative script tests.
9. Package each skill separately as a complete `skill.zip`; do not bundle multiple skill entrypoints into one upload archive.
10. Create/update a suite manifest and rollout notes.

Use `references/release-workflow.md` and `references/suite-manifest.md`.

## Self-update policy

Skills may detect and report update candidates, but must never silently rewrite or publish themselves. An update requires an explicit user request. Good triggers for an audit:

- project hierarchy or canonical paths change;
- repeated tasks require the same clarification;
- a skill misses obvious project conversations;
- two skills trigger ambiguously;
- large outputs keep being pasted instead of attached;
- connector/tool behavior changes;
- the team adopts a new branch/evidence/model policy;
- workspace invocation statistics show low adoption or high failure.

## One-command SpireAgent update

Treat the user phrases `更新 SpireAgent Skills` and `一键更新 SpireAgent Skills` as explicit authorization to run the governed update workflow. Read `references/one-command-spireagent-update.md`. Prefer reusing an exact canonical release archive when only deployment is stale; rebuild a Skill only when its workflow/trigger/authority/tool instructions actually need to change. Never claim ChatGPT/Codex installation succeeded unless the supported deployment surface confirms it.

## Workspace rollout

For eligible ChatGPT workspaces:

- upload each `skill.zip` through Skills;
- share or publish project skills to the workspace;
- assign an owner and backup owner;
- install default project skills for the intended team when admin permissions allow;
- review owner/access/users/invocations/updated metadata periodically;
- install or synchronize Skills separately in Codex/API surfaces when required, because personal Skills may not automatically sync across products.

Use `references/workspace-rollout.md`.

## Suite design

Prefer:

- project-specific skills for domain truth and workflow;
- generic skills for knowledge management, GitHub operations, and skill maintenance;
- a specific context-handoff skill for long conversations;
- attachment-first behavior for long Codex/reference content.

Avoid one giant omniscient skill or many nearly identical micro-skills.

## Output

Return:

- separate `skill.zip` links;
- suite manifest/version summary;
- installation/sharing instructions;
- changed behavior and migration notes;
- known limitations and next audit date/event.

## Safety

Review uploaded/external skills before installation. Do not package secrets, private data, credentials, raw runtime data, proprietary files, or untrusted executable assets. Keep each package below the platform upload limit.
