#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
from pathlib import Path

FRONT = re.compile(r"^---\nname:\s*([a-z0-9-]+)\ndescription:\s*(.+?)\n---\n", re.S)


def audit_skill(skill: Path) -> list[str]:
    errors: list[str] = []
    entry = skill / "SKILL.md"
    meta = skill / "agents" / "openai.yaml"
    if not entry.is_file():
        return [f"{skill.name}: missing SKILL.md"]
    text = entry.read_text(encoding="utf-8")
    match = FRONT.match(text)
    if not match:
        errors.append(f"{skill.name}: invalid frontmatter")
    elif match.group(1) != skill.name:
        errors.append(f"{skill.name}: frontmatter name is {match.group(1)}")
    if len(text.splitlines()) > 500:
        errors.append(f"{skill.name}: SKILL.md exceeds 500 lines")
    if not meta.is_file():
        errors.append(f"{skill.name}: missing agents/openai.yaml")
    for ref in re.findall(r"`(references/[^`]+)`", text):
        if not (skill / ref).is_file():
            errors.append(f"{skill.name}: missing referenced file {ref}")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    args = parser.parse_args()
    skills = sorted(p for p in args.root.iterdir() if p.is_dir() and (p / "SKILL.md").exists())
    errors = [error for skill in skills for error in audit_skill(skill)]
    if errors:
        print("\n".join(errors))
        return 1
    print(f"PASS: {len(skills)} skills")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
