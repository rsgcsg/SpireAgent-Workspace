# Prompt patterns

## Default implementation prompt

```text
Task: <one coherent causal capability>.

First fetch and align <repo/ref/PR>, read <canonical files>, and inspect <exact evidence>. Do not assume the reported result passed.

Goal: <observable outcome>. Autonomously identify the first causal problem and owning layer. Preserve <hard-shell invariants>. Prefer a deeper canonical seam over multiple patches when exact source/runtime evidence justifies it; preserve essential native complexity with small adapters.

Use Sol only for scope/architecture/final acceptance; delegate explicit source work, implementation, tests, docs and commit preparation to Luna-High workers when available.

Implement <2-5 related slices or exact scope>, run <checks>, update <docs/evidence/BOM/PR>, and stop for Human testing only at <runtime gate>. If evidence is clean and the next step is within scope, continue without asking.

Forbidden: <critical non-goals>.

Report: result, files, tests, evidence level, remaining non-claims, next Human path.
```

## Evidence closeout prompt

```text
Audit the latest exact Human/runtime session first. Verify artifact SHA/MVID, runtime, game, Modset, accepted-root accounting, dispositions, causal invariants and audit coverage. Do not infer PASS from the user's statement. Fix only real owning-layer defects. If clean, close evidence/PR and continue to the declared next batch.
```

## Docs-only prompt

Keep docs-only changes on a docs branch, preserve claim levels, update document maps, and do not alter runtime behavior.
