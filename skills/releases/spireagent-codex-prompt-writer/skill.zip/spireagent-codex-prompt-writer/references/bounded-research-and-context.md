# Bounded research, subagents, and context budget

## External research decision

Prefer repository truth and supplied Workspace references. Browse only when a current external fact materially affects the task and is not already covered reliably.

Good reasons:
- current API/product behavior;
- upstream documentation or breaking changes;
- standards, security, compatibility;
- mature public solution comparison.

Default prompt language when needed:

```text
External research:
Use repository and supplied Workspace references first.
If the task materially depends on current external API/product behavior, upstream documentation, standards, security/compatibility, or a mature public solution not already covered, perform a bounded web pass.
Start with 1-3 targeted queries, prefer official/primary sources, expand only for a concrete unresolved gap or contradiction, and stop once the engineering decision is adequately supported.
Do not let every worker independently browse the same shared question; use the lead or one focused research worker and pass a concise finding to implementation workers.
```

Do not inject this block mechanically into tasks that do not need the web.

## Context efficiency

- Establish exact refs and canonical status once.
- Give workers only the files, constraints, and decision context they need.
- Prefer a compact reference packet over pasting long project history into every worker prompt.
- Let the lead review summaries, diffs, test results, and unresolved decisions instead of rereading every file from scratch.
- Reuse recent curated Workspace references instead of repeating broad external searches.

## Subagent decision

Use parallel workers only for genuinely separable work. A single focused agent is cheaper and clearer for a small coherent edit. Shared research should normally have one owner.
