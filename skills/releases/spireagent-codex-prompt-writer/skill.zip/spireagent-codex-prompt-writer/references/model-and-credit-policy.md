# Model and credit policy

## Lead/worker split

Use a strong lead (prefer Sol when available) for:

- initial repository/ref alignment;
- problem framing and competing hypotheses;
- owning-layer and architecture/seam decisions;
- scope boundaries and stop gates;
- final diff/evidence/acceptance review.

Use Luna-High delegated workers by default for explicit bounded work:

- inspect named source files;
- implement a defined adapter or fix;
- add tests;
- update docs/coverage/BOM;
- prepare commits and PR text;
- run deterministic checks and summarize results.

## Efficiency rules

- The lead reads canonical status and establishes exact refs once.
- Workers receive a compact context packet and exact file list.
- Avoid duplicate broad repository scans.
- Parallelize only independent file/mechanism slices.
- Do not use an expensive lead for mechanical docs formatting or repetitive tests.
- Do not let cheap workers decide authority, architecture, or claim promotion without lead review.
- When model names differ, use the cheapest capable worker and one stronger lead.
