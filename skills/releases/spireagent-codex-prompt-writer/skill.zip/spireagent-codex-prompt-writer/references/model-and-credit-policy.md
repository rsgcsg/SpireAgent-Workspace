# Model and credit policy

## Lead/worker split

Use a strong lead for:

- repository/ref alignment;
- problem framing and competing hypotheses;
- owning-layer and architecture/seam decisions;
- scope boundaries and stop gates;
- final diff/evidence/acceptance review.

Use capable delegated workers for bounded work:

- inspect named source files;
- implement a defined adapter/fix;
- add tests;
- update docs/coverage/BOM;
- run deterministic checks;
- summarize findings.

When named models differ, preserve the role split with the strongest practical lead and the cheapest capable worker.

## Efficiency rules

- The lead establishes canonical refs/context once.
- Workers receive a compact context packet and exact file list.
- Avoid duplicate broad repository scans.
- Parallelize only independent workstreams.
- Do not let every worker independently browse the same external question.
- Use one focused research worker for a shared external gap and pass a concise finding to implementation workers.
- Do not use an expensive lead for mechanical formatting or repetitive checks.
- Do not let workers promote authority or evidence claims without lead review.
