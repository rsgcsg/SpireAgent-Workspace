Version: 2.4.0
Updated: 2026-08-28
Scope: owning-repo-first Codex grounding, bounded external research, token-aware progressive context, focused subagent use, and Skill/research reuse instead of repeated broad discovery.
