Version: 2.2.0
Updated: 2026-08-28
Scope: remote-first Workspace/Platform/STPD prompt grounding, exact-ref routing, Human canary cadence, and strong-lead/cheap-worker delegation policy.
