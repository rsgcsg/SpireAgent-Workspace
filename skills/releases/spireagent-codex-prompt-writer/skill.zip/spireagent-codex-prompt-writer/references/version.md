Version: 2.1.1
Updated: 2026-08-28
Scope: short attachment-first Codex prompts, current Workspace/Platform/STPD routing, Human canary cadence, and strong-lead/cheap-worker delegation policy.
