# Project guardrails

- Resolve the active repo/ref before editing.
- Normal Platform/STPD work targets `develop` through a short-lived topic branch/PR.
- Do not direct-push protected `main` or `develop`.
- STS2 remains game truth and Commit authority.
- Connector remains the only Player Environment/action authority.
- Annotator may observe exact accepted Human actions but may not create legality.
- Platform remains model-neutral; STPD remains a research consumer.
- Evidence does not transfer across source/artifact/runtime/game/Modset.
- CI is source/test evidence only.
- Unknown delivery is not retried.
- Do not commit secrets, game binaries, decompiled source, local artifacts, raw Human sessions, saves, model weights, or private paths.
