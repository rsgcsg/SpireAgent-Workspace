# Output rubric

A final Codex prompt should be:

- short enough to scan once;
- autonomous rather than permission-seeking;
- pinned to current repo/ref or instructing Codex to resolve it;
- explicit about goal, hard shell, non-goals, checks, stop gate and deliverable;
- attachment-first for large context;
- clear about Sol lead and Luna-High worker roles when available;
- honest about source/test/build/load/Human/qualification claims;
- scoped to one coherent PR or evidence closeout.
