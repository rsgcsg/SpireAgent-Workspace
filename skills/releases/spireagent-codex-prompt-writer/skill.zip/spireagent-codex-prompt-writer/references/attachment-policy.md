# Codex attachment policy

Use a separate `.md` reference attachment when:

- supporting context exceeds about 600 words;
- more than six constraints or a substantial evidence matrix is needed;
- the task spans multiple repositories/workstreams;
- the user requests a complete reference document;
- a conversation handoff is needed.

Keep the top-level prompt short. Preferred pair:

- `CODEX_PROMPT_<task>_<date>.txt`
- `CODEX_REFERENCE_<task>_<date>.md`

The prompt must identify the attachment and say repository/runtime facts override it. Do not paste the full attachment into chat after creating it.
