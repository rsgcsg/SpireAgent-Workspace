# Full-Run workflow

Current project direction should be read from GitHub. When Full-Run Human Semantic is active, use:

```text
ordinary-combat regression oracle
-> coherent Combat mechanism batches
-> lethal/reward/map cross-surface canaries
-> non-combat room mechanisms
-> run entry/terminal
-> longer natural run
-> continuous Full Run
```

Prioritize mechanism families, not individual cards/content. Default 2-5 related slices per canary. A long run is a discovery tool: preserve evidence, fix the first causal failure, then continue.

Hard stops:

- false S->A->S';
- wrong Human binding;
- missing accepted-root accounting;
- proof crossing another Human effect;
- duplicate delivery/execution;
- cancellation recorded as success;
- silent timeline reset;
- Connector authorizing an incomplete/illegal catalog;
- downstream code masking an upstream truth defect.
