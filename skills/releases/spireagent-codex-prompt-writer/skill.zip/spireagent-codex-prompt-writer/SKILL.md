---
name: spireagent-codex-prompt-writer
description: "Write, review, tighten, or split Codex prompts for the current SpireAgent workspace, STS2 AI Platform, STPD, Connector, Annotator, Full-Run, Human evidence, Policy Runtime, GitHub branches, and PR-sized implementation work. Use when the user asks to give Codex a task, convert rough Chinese engineering intent into a prompt, choose a scope/route, prepare a large Codex reference attachment, review a Codex prompt, or coordinate Sol with Luna-High delegated workers while saving credit."
---

# SpireAgent Codex Prompt Writer

## Mission

Produce Codex instructions that are short, autonomous, clear, complete, current-ref-aware, and protective of project authority. Respond in Chinese by default. Do not directly edit the repository; remote-edit requests belong to `github-remote-operator` or Codex itself.

## Default output contract

1. Give one concise Codex prompt, normally 180-450 words.
2. Keep the prompt self-contained enough to start, but do not paste a large project history into it.
3. If the task needs detailed architecture, evidence matrices, historical decisions, exact test paths, or more than roughly 600 words of supporting context, create a separate Markdown attachment and make the prompt say: `Read <attachment> first; current repository/runtime evidence overrides it.`
4. In chat, show only a short summary and links to the prompt/reference attachments.
5. Use Chinese prompts unless the user requests English.

Read `references/attachment-policy.md` and `references/prompt-patterns.md`.

## Grounding before writing

- Resolve current repository, branch/PR, and exact SHA when the prompt depends on current state.
- For Platform, normal work starts from current `origin/develop` and uses a short-lived topic branch unless the prompt is explicitly continuing an existing branch/PR.
- For STPD, preserve its separate repository and exact Platform dependency pin.
- Read current `AGENTS.md`, status/roadmap, the relevant component/coverage/evidence files, and the active PR before writing.
- Do not hardcode a historical phase or path when current GitHub can resolve it.

## Model and credit policy

When the Codex environment exposes GPT-5.6 Sol, Luna-High, and delegated workers:

- Use Sol as the lead only for high-value work: scope, assumptions, competing hypotheses, owning-layer decision, architecture/seam choice, stop/continue gate, and final acceptance review.
- Delegate explicit bounded work to Luna-High by default: targeted source inspection, local implementation, tests, documentation, coverage updates, cleanup, commit preparation, and deterministic evidence checks.
- Give each worker a small file list, exact base/ref, clear output, and non-goals. Do not pay multiple agents to reread the same repository broadly.
- Let Sol review summaries/diffs/results, not every low-level file from scratch.
- If named models or subagents are unavailable, preserve the role split using the cheapest capable delegated worker and one stronger lead.

Read `references/model-and-credit-policy.md`.

## Scope and autonomy

A good prompt tells Codex to:

- fetch and align remote state first;
- identify the first causal problem and owning layer;
- preserve exact evidence classes;
- make the smallest clean change or a justified deeper canonical change;
- prefer 2-5 related slices sharing one real mechanism over one-button tasks;
- stop for Human testing only at a meaningful runtime gate;
- continue automatically when evidence is clean and the next slice is within the declared mainline;
- update canonical docs/evidence/BOM/PR metadata when claims change;
- report changed files, checks, evidence, non-claims, and next Human path.

Do not make prompts timid. Avoid repeated confirmation requests when repository evidence can resolve the choice. Do not make prompts sprawling: one PR should express one coherent causal capability, though it may contain several related slices.

## Project hard shell

Every implementation prompt must preserve:

- STS2 owns rules, RNG, effects, native legality, and Commit.
- Connector owns fair-player state/actions, Host-local bindings, execute-time revalidation, Receipt, and successor semantics.
- Annotator observes Human actions and evidence; it does not reconstruct legality.
- H is not S; execution/Commit consumes S; no proof crosses another Human effect.
- Unknown delivery/outcome is not retried or backfilled from a later frame.
- Platform remains model-neutral; STPD model/checkpoint changes cannot mask Platform defects.
- No secrets, proprietary game files, local artifacts, raw Human data, or model weights enter Git.

Use `references/project-guardrails.md`.

## Human test cadence

Default cadence:

```text
2-5 related slices -> automated checks -> short Human canary -> fix owning defect -> next batch
```

A mature shared mechanism may cover 4-6 related slices before a canary. Stop early only for a correctness defect, a new critical native seam, an authority change, or a decision that depends on real timing/cancellation/scene behavior. After 2-3 clean short canaries, request a longer natural run.

See `references/full-run-workflow.md`.

## Prompt review

For prompt review, return:

- verdict: accept / accept with changes / reject;
- current ref/phase fit;
- scope and hard-shell risk;
- missing repository reads;
- missing stop gate/tests/evidence;
- a rewritten prompt.

## Remote-first current truth

For current-state work, load `references/remote-authority.md` and refresh GitHub before substantive project claims. Keep mutable project status out of this Skill; the Skill should change mainly when triggers, routing, authority boundaries, or tool workflow change.

## Self-update

On an explicit skill-update request, route through `workspace-skill-maintainer` and `skill-creator`. Use recent successful and failed Codex tasks as concrete examples, update templates/model policy, validate, and return a complete `skill.zip`.
