# Attachment-first policy

Create a Markdown attachment instead of pasting a large block inline when any condition holds:

- expected output exceeds roughly 900 words;
- more than one large table or evidence matrix is needed;
- the answer is intended for Codex or a new chat;
- more than two workstreams or repositories must be reconciled;
- the user asks for a complete reference document.

Inline response should contain:

- 3-8 key conclusions;
- exact current ref/evidence boundary;
- one next action;
- a link to the attachment.

Use descriptive names such as:

- `SPIREAGENT_CURRENT_STATUS_<date>.md`
- `SPIREAGENT_ARCHITECTURE_REVIEW_<date>.md`
- `CODEX_REFERENCE_<task>_<date>.md`
- `SPIREAGENT_CONTEXT_HANDOFF_<date>.md`
