# Workflow status and bounded web research

## Overall workflow status

For broad status requests, check only relevant planes and label each independently:

- Workspace governance / current-pointer drift;
- Workspace Skill deployment and product state;
- Platform active branch/PR plus source/runtime/Human gate;
- STPD engineering and scientific blockers;
- repo Agent OS / memory / repo-owned Skill maturity when relevant.

Never collapse local validation, CI, runtime, Human evidence, product deployment, and scientific claims into one status flag.

## When to browse

Browse when a current external fact materially affects the answer and repository/curated Workspace material is insufficient, including current product/API/SDK behavior, upstream compatibility, standards/advisories, or mature public tools.

Use a small targeted query set, prefer official/primary sources, expand only for a concrete gap or contradiction, and stop once the decision is supported. Curated Workspace references should be reused when recent enough.
