# Current SpireAgent project model

## Workspace hierarchy

```text
SpireAgent workspace
├── STS2 AI Platform Foundation
│   ├── Host Runtime and exact identity
│   ├── Connector / Player Environment
│   ├── Human Annotator and Evidence
│   ├── model-neutral Policy Runtime
│   └── Workbench, Live UI, unified Mod
└── Research projects
    └── STPD
        ├── research projection and datasets
        ├── representation and serialization
        ├── models and adapters
        ├── training and evaluation
        └── experiment provenance
```

## Repositories

- Platform: `rsgcsg/STS2-AI-PLATFORM`.
- STPD: `rsgcsg/STS2-The-Perfect-Defect`.

Both use a governed `main` / `develop` / short-lived topic branch workflow. Resolve the current active branch before every current-state claim.

## Authority direction

```text
STS2 native runtime
  -> Platform Foundation contracts and evidence
  -> STPD research consumption
```

Platform must not import STPD checkpoints, rewards, training, research projection, or policy semantics. STPD must not reconstruct native legality, hidden state, native operands, Receipt truth, or successor truth.

## Historical lineage

Old SpireAgent/P8-P15, Re-SpireAgent, Bridge-v2, STS2MCP, and headless design records remain useful when the user asks for lineage or when current docs cite them. Do not treat them as the current active repository model without fresh proof.
