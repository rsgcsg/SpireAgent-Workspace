# Current SpireAgent system model

## Collaboration and authority planes

```text
ChatGPT Workspace / Library
  -> human/ChatGPT working knowledge, reusable files, larger references

rsgcsg/SpireAgent-Workspace
  -> small versioned Codex-facing relay: governance, routing, shared standards,
     Workspace Skills, handoffs, knowledge pointers, selected cross-project references

rsgcsg/STS2-AI-PLATFORM
  -> model-neutral Platform implementation/contracts/runtime/evidence authority

rsgcsg/STS2-The-Perfect-Defect
  -> STPD research/data/model/training/evaluation authority
```

Routine Platform/STPD work should work without Workspace. Workspace/Library context may enrich work but does not override owning-repo truth.

## Authority direction

```text
STS2 native runtime
  -> Platform Foundation contracts/evidence
  -> STPD research consumption
```

Platform must not import STPD checkpoints, rewards, training, research projection, or policy semantics. STPD must not reconstruct native legality, hidden state, native operands, Receipt truth, or successor truth.

## Historical lineage

Old SpireAgent/P8-P15, Re-SpireAgent, Bridge-v2, STS2MCP, and headless design records remain lineage unless current canonical repositories explicitly reactivate them.
