Version: 2.3.0
Updated: 2026-08-28
Scope: four-plane Workspace/Library/relay/owning-repo model, remote-first current truth, bounded external research, workflow-level status checks, and strict evidence separation.
