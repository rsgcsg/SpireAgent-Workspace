Version: 2.1.1
Updated: 2026-08-28
Scope: current Workspace/Platform/STPD project model, exact-ref GitHub freshness, Full-Run evidence discipline, attachment-first output, and skill routing.
