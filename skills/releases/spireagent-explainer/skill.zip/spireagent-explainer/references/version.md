Version: 2.2.0
Updated: 2026-08-28
Scope: remote-first current Workspace/Platform/STPD inspection, exact-ref GitHub freshness, evidence discipline, and stable workflow-shell semantics.
