# Conversation grounding

Classify material statements as:

- repo-confirmed current fact;
- current canonical repository record;
- exact runtime evidence;
- user-reported local validation;
- accepted conversation decision;
- working engineering judgment;
- proposal only;
- rejected/superseded;
- disputed;
- needs repository verification;
- needs source/runtime evidence.

Priority for current implementation claims:

```text
pinned current code + exact runtime evidence
> current canonical docs
> historical closeout within its exact scope
> accepted conversation direction
> proposal, archive, recollection
```

A later conversation may change the desired direction but cannot rewrite historical evidence or prove implementation. Uploaded assistant summaries are records of prior assertions, not proof that all underlying sources were checked.

When prior chats matter, state which visible/shared/uploaded records were used and which conclusions remain unverified.
