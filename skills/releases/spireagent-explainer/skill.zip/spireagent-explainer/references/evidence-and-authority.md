# Evidence and authority

## Evidence ladder

1. Conversation proposal.
2. Current source present.
3. Source tests pass.
4. Exact build produced.
5. Exact artifact installed.
6. Exact artifact cold-loaded with SHA/MVID/runtime/game/Modset identity.
7. Targeted Human/runtime canary exercised.
8. Longer journey or bounded qualification.
9. Governed release claim.

Never skip levels in prose.

## Hard shell

- Fair-player information only.
- Complete finite BoundActions before mutation authority.
- Host-local native operands.
- Execute-time native revalidation.
- Single current input owner.
- Request idempotency.
- Unknown delivery is never retried.
- Human observation H is not semantic S.
- Real execution/Commit consumes S.
- No transition proof may cross another Human semantic effect.
- Cancel/abort cannot become a fake successful transition.
- Source/test/build evidence never inherits Human runtime authority.
