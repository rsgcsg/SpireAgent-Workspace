# GitHub freshness protocol

1. Resolve repository metadata and all relevant branches/PRs.
2. Determine the user-relevant ref from project context; do not infer it from the default branch.
3. Pin the ref to an exact SHA before reading files.
4. Read canonical status/document maps before implementation details.
5. For changes, inspect 2-7 recent commits or compare exact refs.
6. Search results are orientation only; branch/PR APIs establish topology.
7. Name the exact repo/ref/SHA and inspected files in the answer.
8. If a later commit is readable but no named branch resolves, call it a latest verifiable snapshot, not a branch head.
9. Retry one failed read once with a smaller range. Treat truncation as a display artifact and inspect targeted files/lines.
10. Keep GitHub call scope tight: normally 4-12 targeted reads.

## Platform read set

Start with:

- `AGENTS.md`
- `docs/STATUS.md`
- `docs/ROADMAP.md`
- `docs/ARCHITECTURE.md`
- `docs/DOCUMENT_MAP.md`
- `docs/DEVELOPMENT_WORKFLOW.md` for branch/PR questions

Then read the relevant component, coverage matrix, evidence closeout, BOM, tests, or PR.

## STPD read set

Start with:

- `AGENTS.md`
- `docs/DOCUMENT_MAP.md`
- `docs/STATUS.md`
- `docs/memory/CURRENT.md`
- `docs/memory/DECISIONS.md`
- `docs/DEVELOPMENT_WORKFLOW.md`

Then read the relevant environment/data/model/training/evaluation files.

## Write boundary

This skill is read-first. If the user explicitly requests remote edits, route to `github-remote-operator`; do not improvise direct writes inside an explanation workflow.
