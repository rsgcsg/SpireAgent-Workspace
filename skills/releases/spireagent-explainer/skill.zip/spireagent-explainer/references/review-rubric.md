# Review rubric

Review a plan, PR, or architecture across:

1. Owning layer: is the defect fixed where truth lives?
2. Causal model: are H, S, action execution/Commit, S', cancellation, and terminal states distinct?
3. Authority: does STS2 remain the rules/effects engine and Connector remain the only action authority?
4. Evidence: which claims are source/test/build/load/Human/qualification?
5. Complexity: does a deeper canonical seam remove accidental complexity, or is it speculative?
6. Essential complexity: are genuinely different native mechanisms represented by small explicit adapters rather than a fake mega-abstraction?
7. Maintainability: is responsibility localized, testable, and explainable?
8. Branch/PR fit: one coherent causal capability, exact base SHA, clear non-goals and rollback.
9. Cross-repo fit: Platform contract first, STPD exact pin second.
10. Stop gate: what must be Human-tested before further expansion?

Give a verdict: accept, accept with changes, or reject. Name the first causal risk, not a list of cosmetic issues.
