# Dated fallback snapshot — 2026-08-28

Use only when live GitHub inspection is unavailable.

At the last verified point:

- Platform `main@5604050...` was a frozen pre-governance baseline, not a stable release.
- Platform `develop@b9db319...` contained schema-2 Human closeout.
- Active Full-Run topic branch was `feature/annotator/full-run-semantic-mainline@b16bd502...`.
- Full-Run repair source `c8775e1...`, artifact `8d2f7d2a... / 3043f4f4...`, was built, installed, and cold-loaded; Human repair-canary evidence remained pending in the remote record.
- STPD `main@4c4bbca...` was the frozen pre-governance baseline and `develop@ae4c8ac...` the governed integration line.

This snapshot becomes stale immediately after new commits or Human evidence. Refresh before making current claims.
