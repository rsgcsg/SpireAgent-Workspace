---
name: spireagent-conversation-organizer
description: "Turn SpireAgent conversations, meeting notes, PR/run discussions, and uploaded histories into maintainable engineering knowledge without turning chat memory into repository truth. Use to extract decisions, proposals, rejected ideas, open questions, action items, evidence claims, Codex task candidates, handoff/reference candidates, or cross-project workflow status. Verify exact repository truth when current state matters and route durable knowledge to Workspace/Library, the small SpireAgent-Workspace relay, or the owning repository according to authority."
---

# SpireAgent Conversation Organizer

## Mission

Turn SpireAgent conversations into maintainable engineering knowledge without promoting conversation memory into repository truth. Respond in Chinese by default. This Skill is read-first and does not write GitHub.

## Current authority model

Use `references/project-context.md`.

- ChatGPT Workspace/Library: working conversations, larger references, reusable files, and human/ChatGPT collaboration.
- `rsgcsg/SpireAgent-Workspace`: small versioned Codex-facing relay for governance, routing, Workspace Skills, shared standards, handoffs, knowledge pointers, and selected cross-project snapshots.
- `rsgcsg/STS2-AI-PLATFORM`: Platform implementation/contracts/runtime/evidence authority.
- `rsgcsg/STS2-The-Perfect-Defect`: STPD research/data/model/training/evaluation authority.

Historical P8-P15/Context OS vocabulary is lineage unless current canonical repositories explicitly reactivate it.

## Grounding workflow

1. Identify conversation sources actually available: visible chat, pasted/exported transcript, uploaded notes, GitHub discussion, or mixed sources.
2. If current project truth matters, verify exact remote refs before calling anything current.
3. Classify each material statement as one of:
   - repo-confirmed;
   - runtime/Human-confirmed;
   - accepted conversation decision;
   - proposal;
   - rejected;
   - disputed;
   - stale/superseded;
   - needs GitHub verification;
   - needs runtime/Human verification.
4. Preserve evidence classes: source/test/CI, build/install/load, Human runtime, and scientific evidence are distinct.
5. Extract only artifacts useful for the user's requested outcome.

## Knowledge promotion

Use `references/knowledge-promotion.md`.

- Conversation-only working material or large reusable references -> Workspace/Library when available.
- Small reviewed cross-project rule, pointer, handoff, or shared standard -> `SpireAgent-Workspace` candidate.
- Implementation/runtime/research truth -> owning repository.
- Do not duplicate a long public reference into every digest if a curated Workspace reference already exists; point to it.

This Skill may recommend promotion but does not itself write GitHub.

## Repository reads when alignment is requested

Start with Workspace governance only when routing/cross-project context matters, then refresh the owning repository at an exact ref. Use current `AGENTS.md`, status/document maps, active PRs, memory, and task-specific evidence instead of old transcript claims.

## Default output

Use `references/output-templates.md` when helpful. Typical sections:

- Scope / sources / exact refs checked;
- Executive summary;
- Confirmed project truths;
- Decisions;
- Proposals and rejected ideas;
- Open questions;
- Action items with owning layer;
- Docs/ADR impacts;
- Codex task candidates;
- Evidence gaps/blockers;
- one concrete next step.

For broad workflow discussions, add Workspace governance, Skill deployment, Platform, STPD, and Agent OS/tooling only when they materially help.

## Routing and guardrails

- Remote write -> `github-remote-operator`.
- Current-state/architecture dispute -> `spireagent-explainer`.
- Codex prompt -> `spireagent-codex-prompt-writer`.
- Context saturation -> `spireagent-context-handoff`.
- Never infer unseen chats.
- Never say GitHub was checked unless it was checked in the current task.
- Never promote green CI to runtime/Human/scientific evidence.
- Never let Workspace override exact Platform/STPD truth.

## Self-update

On explicit update requests, use `workspace-skill-maintainer` plus built-in `skill-creator`. The working Project chat audits the recurring failure/use case and prepares the exact change; the reliable default product path is `Plugins -> Skills -> Create -> Create with chat`, where a dedicated Skill Chat updates the existing Skill and completes native save/install. Do not create a duplicate.
