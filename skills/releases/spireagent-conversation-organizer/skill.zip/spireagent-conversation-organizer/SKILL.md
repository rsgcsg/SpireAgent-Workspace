---
name: spireagent-conversation-organizer
description: "Organize SpireAgent / Slay the Spire AI team conversations, shared-project chats, pasted transcripts, meeting notes, GitHub issue/PR discussions, Codex planning chats, run reviews, and architecture debates into engineering digests, decisions, action items, ADR drafts, docs-update suggestions, handoffs, and Codex task candidates. Use for requests such as 整理 SpireAgent 对话, 团队讨论总结, conversation digest, meeting notes, ADR, docs patch, handoff, or connecting discussion conclusions to the current SpireAgent-Workspace / Platform / STPD repositories."
---

# SpireAgent Conversation Organizer

## Mission

Turn SpireAgent conversations into maintainable engineering knowledge without turning conversation memory into repository truth. Respond in Chinese by default.

This skill is read-first. It does not write GitHub. Route explicit remote changes to `github-remote-operator`; route current-state/architecture disputes to `spireagent-explainer`; route new-chat overflow to `spireagent-context-handoff`; route Codex prompts to `spireagent-codex-prompt-writer`.

## Current authority model

Treat the current workspace as:

```text
rsgcsg/SpireAgent-Workspace
  -> governance, routing, Skill source/version, handoffs, shared instructions

rsgcsg/STS2-AI-PLATFORM
  -> Platform Foundation code/contracts/runtime/evidence

rsgcsg/STS2-The-Perfect-Defect
  -> STPD research projection/data/model/training/evaluation
```

Historical P8-P15 / hard-shell / soft-shell / Context OS documents are lineage unless current canonical repositories explicitly reactivate them. Never classify current work by historical phases merely because a transcript mentions them.

Read `references/project-context.md` when project-specific grounding is needed.

## Grounding workflow

1. Identify the conversation sources actually available: visible chat, pasted/exported transcript, uploaded notes, GitHub discussion, or mixed sources.
2. If current repository truth matters, use `spireagent-workspace-governor` routing and verify exact remote refs through GitHub before calling anything current.
3. Classify every material statement as one of:
   - repo-confirmed;
   - runtime/Human evidence-confirmed;
   - explicitly accepted conversation decision;
   - proposal;
   - disputed;
   - stale/superseded;
   - needs GitHub verification;
   - needs runtime/Human verification.
4. Separate repository authority from conversation evidence. A conversation can propose a change; it cannot silently promote itself to current status.
5. Preserve evidence boundaries: source/test/CI, build/install/load, Human runtime, and scientific evidence are different classes.

## Repository reads when alignment is requested

Start with governance:

- `rsgcsg/SpireAgent-Workspace/WORKSPACE_ROUTER.md`
- `workspace/CURRENT.md`
- `workspace/SOURCE_OF_TRUTH.md`
- `skills/SKILL_SUITE_MANIFEST.json`
- `workspace/HANDOFF.md` when continuity matters

Then refresh the owning repository at an exact ref.

For Platform conversations, prioritize current `AGENTS.md`, `docs/STATUS.md`, `docs/ROADMAP.md`, `docs/ARCHITECTURE.md`, `docs/DOCUMENT_MAP.md`, the active PR, and task-specific evidence/coverage files.

For STPD conversations, prioritize current `AGENTS.md`, `docs/DOCUMENT_MAP.md`, `docs/STATUS.md`, `docs/memory/CURRENT.md`, `docs/memory/DECISIONS.md`, and task-specific research/evidence files.

## Default workflow

Read `references/organizer-workflow.md` for the full process. In short:

1. Extract decisions, proposals, rejected ideas, open questions, action items, docs impacts, Codex candidates, evidence claims, and authority risks.
2. Assign each item to an owning layer: Workspace governance, Platform, STPD, conversation-only, or external dependency.
3. Mark exact evidence class and verification needs.
4. Produce only the artifacts useful for the user's request.
5. Keep blockers and unresolved gates visible rather than burying them in chronology.

## Output

Use `references/output-templates.md` as needed. Default digest sections:

- Scope / sources / exact refs checked;
- Executive summary;
- Confirmed project truths;
- Decisions made;
- Proposals and rejected ideas;
- Open questions;
- Action items with owning repo/layer;
- Docs/ADR updates suggested;
- Codex task candidates;
- Evidence gaps / blockers;
- one concrete next step.

For long histories, create an attachment rather than pasting a giant transcript-derived report inline.

## Guardrails

- Never infer unseen chats.
- Never say GitHub was checked unless it was checked in the current task.
- Never let `SpireAgent-Workspace` override exact Platform/STPD implementation truth.
- Never promote green CI to runtime/Human/scientific evidence.
- Never convert historical P8-P15 terminology into the current project model without current-repo proof.
- Never write GitHub from this skill.

## Remote-first current truth

For current-state work, load `references/remote-authority.md` and refresh GitHub before substantive project claims. Keep mutable project status out of this Skill; the Skill should change mainly when triggers, routing, authority boundaries, or tool workflow change.

## Self-update

If recurring conversations expose stale project paths, phase assumptions, routing errors, or missing output fields, update this skill only on explicit user request through `workspace-skill-maintainer` + `skill-creator`, then validate/package a complete replacement `skill.zip`.
