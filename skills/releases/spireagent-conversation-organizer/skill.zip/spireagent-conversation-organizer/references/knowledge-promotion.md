# Conversation knowledge promotion

## Classification before promotion

A conversation statement must first be labeled as confirmed, accepted decision, proposal, rejected, disputed, stale/superseded, or needing verification. Frequency in chat is not authority.

## Destination

- Large reusable context/reference or working report -> Workspace/Library when available.
- Small reviewed cross-project rule, pointer, shared standard, or handoff -> `SpireAgent-Workspace` candidate.
- Implementation/runtime/evidence/research truth -> owning repository.
- Unverified speculation -> conversation only until verified.

Prefer pointers to curated references over copying long material into every digest. Promotion through GitHub requires `github-remote-operator` and explicit user authorization.
