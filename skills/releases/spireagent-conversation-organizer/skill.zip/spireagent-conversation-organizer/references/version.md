Version: 2.4.0
Updated: 2026-08-28
Scope: conversation-to-knowledge promotion across Workspace/Library, small durable Workspace relay, and owning repos; exact-ref grounding; evidence classification; and reuse of curated references instead of repeated context copies.
