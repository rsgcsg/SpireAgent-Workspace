Version: 2.2.0
Updated: 2026-08-28
Scope: current Workspace -> Platform Foundation -> STPD authority model; exact-ref GitHub grounding; evidence-class separation; historical P8-P15 demotion to lineage only.
