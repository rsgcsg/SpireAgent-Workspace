Version: 2.3.0
Updated: 2026-08-28
Scope: remote-first Workspace -> Platform Foundation -> STPD authority model, exact-ref grounding, evidence-class separation, and historical phase demotion.
