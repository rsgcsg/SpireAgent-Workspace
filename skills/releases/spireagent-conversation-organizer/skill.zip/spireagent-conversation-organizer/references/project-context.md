# Current SpireAgent Project Context

Use this reference only for organizing current SpireAgent discussions. Exact repository refs and runtime evidence override it.

## Authority map

- `rsgcsg/SpireAgent-Workspace`: workspace governance, routing, Skill source/version manifest, handoffs, shared instructions, knowledge pointers.
- `rsgcsg/STS2-AI-PLATFORM`: model-neutral Platform Foundation; Connector, Host Runtime, Human Annotator, Evidence, Policy Runtime, Workbench/Live UI and exact runtime/evidence contracts.
- `rsgcsg/STS2-The-Perfect-Defect`: STPD research project; research projection, data, model, training and evaluation.

Platform is the upper-level environment foundation. STPD is an independently governed research project built on exact Platform contracts, not a peer platform.

## Hard authority boundaries

- STS2 owns rules, RNG, effects, native legality and Commit.
- Connector owns fair-player Snapshot/Read/BoundAction, Host-local native binding, execute-time revalidation, Receipt and successor semantics.
- Annotator owns Human correlation/lifecycle/boundary observation/semantic evidence/session accounting; it does not own legality.
- Platform remains model-neutral.
- STPD owns research/data/model/training/evaluation.

## Evidence classes

Keep separate:

1. current code/source;
2. source/test/CI evidence;
3. build/install/load evidence;
4. Human runtime evidence;
5. qualification/release claim;
6. scientific/research evidence.

Never transfer evidence across source SHA, artifact SHA/MVID, runtime, game version, Modset, repository, branch or environment unless explicitly proven.

## Current repository entry points

### Workspace
- `WORKSPACE_ROUTER.md`
- `workspace/CURRENT.md`
- `workspace/SOURCE_OF_TRUTH.md`
- `skills/SKILL_SUITE_MANIFEST.json`
- `workspace/HANDOFF.md`

### Platform
- `AGENTS.md`
- `docs/STATUS.md`
- `docs/ROADMAP.md`
- `docs/ARCHITECTURE.md`
- `docs/DOCUMENT_MAP.md`
- active PR and task-specific evidence/coverage

### STPD
- `AGENTS.md`
- `docs/DOCUMENT_MAP.md`
- `docs/STATUS.md`
- `docs/memory/CURRENT.md`
- `docs/memory/DECISIONS.md`
- task-specific research/evidence docs

## Historical lineage

P8-P15, hard-shell/soft-shell, ProtectedPathGate, LearningProposal, ReverseScaffoldFeedback, Context OS, Compute/Budget OS and older SpireAgent repository structures are historical lineage unless current canonical repos explicitly reactivate them. Preserve them when summarizing history, but label them historical/superseded instead of treating them as current phase authority.
