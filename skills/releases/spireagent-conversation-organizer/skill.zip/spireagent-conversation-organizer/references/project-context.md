# Current SpireAgent Project Context

Use this reference for organizing current SpireAgent discussions. Exact repository refs and runtime evidence override it.

## Authority map

- ChatGPT Workspace/Library: human/ChatGPT working knowledge, conversations, larger references, reusable files, and handoff material when accessible.
- `rsgcsg/SpireAgent-Workspace`: small versioned Codex-facing relay for governance, routing, Workspace Skill source/release state, handoffs, shared standards, knowledge pointers, and selected cross-project snapshots.
- `rsgcsg/STS2-AI-PLATFORM`: model-neutral Platform Foundation implementation/contracts/runtime/evidence authority.
- `rsgcsg/STS2-The-Perfect-Defect`: STPD research/data/model/training/evaluation authority.

Routine single-repository work does not require Workspace. Workspace material is context/pointer/cache unless explicitly canonical for Workspace governance.

## Hard authority boundaries

- STS2 owns rules, RNG, effects, native legality and Commit.
- Connector owns fair-player Snapshot/Read/BoundAction, Host-local native binding, execute-time revalidation, Receipt and successor semantics.
- Annotator owns Human correlation/lifecycle/boundary observation/semantic evidence/session accounting; it does not own legality.
- Platform remains model-neutral.
- STPD owns research/data/model/training/evaluation.

## Evidence classes

Keep separate current code, source/test/CI, build/install/load, Human runtime, qualification/release, and scientific evidence. Do not transfer evidence across identities without proof.

## Historical lineage

P8-P15, old hard-shell/soft-shell terminology, Context OS, and older repository layouts are lineage unless current canonical repositories explicitly reactivate them.
