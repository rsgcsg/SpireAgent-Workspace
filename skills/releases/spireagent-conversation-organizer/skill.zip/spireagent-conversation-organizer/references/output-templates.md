# Output Templates

## Team Conversation Digest

```markdown
# SpireAgent Conversation Digest

## Scope
- Sources used:
- Exact GitHub refs checked:
- Date range:

## Executive Summary
- ...

## Confirmed Project Truths
- Claim:
  - Authority: Workspace / Platform / STPD
  - Evidence class:
  - Exact ref/source:

## Decisions Made
- Decision:
  - Rationale:
  - Status:
  - Owning repo/layer:
  - Follow-up:

## Proposals / Rejected Ideas
- Item:
  - Status: proposed / rejected / superseded / needs evidence
  - Why:

## Open Questions
- Question:
  - Resolver/evidence needed:

## Action Items
- Task:
  - Owner if known:
  - Owning repo/layer:
  - Target file/code area:

## Docs / ADR Updates Suggested
- File:
  - Suggested change:
  - Evidence boundary:

## Codex Task Candidates
- Task:
  - Repository/base ref:
  - Allowed scope:
  - Forbidden changes:
  - Stop gate:

## Risks / Blockers
- Source-of-truth drift:
- Runtime/Human gates:
- Scientific gates:

## Recommended Next Step
- ...
```

## ADR Draft

```markdown
# ADR: <title>

## Status
Proposed / Accepted / Superseded

## Context

## Decision

## Authority / Owning Layer

## Evidence and Non-Claims

## Consequences

## Follow-up Tasks
```

## Current Status Patch Suggestion

```markdown
## Current Objective

## Exact Ref / Evidence Scope

## Confirmed

## Not Yet Proven

## Current Blockers

## Next Gate
```

## Codex Task Seed

```text
Repository / base SHA:
Task:
Must read:
Allowed changes:
Forbidden changes:
Acceptance criteria:
Evidence level:
Human/runtime stop gate:
```
