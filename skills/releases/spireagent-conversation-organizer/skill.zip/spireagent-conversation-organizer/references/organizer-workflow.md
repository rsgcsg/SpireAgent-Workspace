# Conversation Organization Workflow

## 1. Determine source coverage

Record what is actually available: visible chat, pasted transcript, uploaded export, meeting notes, GitHub issue/PR discussion, or mixed sources. Do not infer unseen conversations.

## 2. Refresh authority when needed

If the user asks for current-state alignment, docs updates, PR/task recommendations, or evidence interpretation:

1. read the Workspace router/current/source-of-truth/manifest;
2. resolve the owning Platform or STPD exact ref through GitHub;
3. read only the canonical files needed for the discussion;
4. record exact SHA/PR used.

## 3. Extract engineering signals

Extract:

- decisions and rationale;
- rejected/superseded ideas;
- pending proposals;
- open questions;
- action items;
- architecture/contract changes;
- docs/ADR impacts;
- Codex task candidates;
- run/evidence claims;
- ownership/authority risks.

## 4. Classify truth and evidence

For each material item, mark:

- repo-confirmed;
- Human/runtime-confirmed;
- explicitly accepted conversation decision;
- proposal;
- disputed;
- stale/superseded;
- needs GitHub verification;
- needs Human/runtime verification.

Also label source/test/CI vs build/load vs Human runtime vs scientific evidence.

## 5. Assign owning layer

Use one of:

- Workspace governance;
- Platform Foundation;
- STPD research;
- external dependency;
- conversation-only / historical lineage.

Do not let governance docs redefine Platform/STPD implementation truth.

## 6. Produce useful artifacts

Depending on the request, produce a concise digest, ADR draft, current-status patch suggestion, handoff, docs-update plan, Codex task list, or meeting summary. For long outputs, use an attachment.

## 7. Final checks

Before finalizing, verify:

- current claims are exact-ref grounded when GitHub is available;
- historical P8-P15 terminology is not presented as current unless reactivated;
- green CI is not described as Human/runtime/scientific proof;
- proposals are not silently promoted to repository truth;
- action items name the owning repo/layer;
- one concrete next step is visible.
