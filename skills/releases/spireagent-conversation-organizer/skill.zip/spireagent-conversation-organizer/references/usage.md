# Usage and Troubleshooting

## Manual invocation examples

- "使用 spireagent-conversation-organizer，整理最近 SpireAgent 团队对话"
- "把这段 Platform Full-Run 讨论整理成 decisions / blockers / docs updates / Codex tasks"
- "整理 STPD 训练讨论，并和当前 GitHub STATUS/CURRENT 对齐"
- "把这个 PR review 讨论整理成 ADR draft 和后续任务"
- "根据上传的历史聊天生成 SpireAgent handoff digest"

## Inputs

The skill can organize visible conversation context, pasted transcripts, uploaded history/notes, and GitHub discussions available to the current task. It must not invent unseen shared-project conversations.

## GitHub alignment

When current repository truth matters, use the GitHub connector and exact refs. Start from `rsgcsg/SpireAgent-Workspace` for routing, then verify the owning Platform/STPD repository.

If GitHub is unavailable, still organize provided content and mark repository-sensitive claims as `Needs GitHub verification`.

## Historical terms

Older P8-P15, hard-shell/soft-shell, Context OS and related vocabulary may appear in transcripts. Preserve them as historical context when useful, but do not present them as the current project phase unless current canonical repositories explicitly say so.
