---
name: workspace-knowledge-librarian
description: "Inspect, organize, index, deduplicate, and govern a ChatGPT workspace knowledge base using shared Projects, Library files, uploaded documents, connected apps, and GitHub sources. Use when the user asks to manage the knowledge library, create a source-of-truth map, classify canonical/current/evidence/handoff/archive files, find stale or duplicate documents, prepare project instructions, or improve cross-team discoverability. For SpireAgent content, combine with the project-specific skills rather than redefining project truth."
---

# Workspace Knowledge Librarian

## Mission

Create a small, trustworthy knowledge map instead of a large undifferentiated file pile. Respond in the user's language. This skill is workspace-generic; SpireAgent-specific meaning remains with the SpireAgent skills.

## Sources

Use only sources actually available in the task:

- shared ChatGPT Project files/chats/instructions;
- ChatGPT Library files;
- uploaded attachments;
- connected Drive/SharePoint or other apps when available;
- GitHub repositories and PRs;
- user-provided folders/exports.

Do not claim direct access to Library or a connector that is unavailable. If an external app would materially help, use plugin discovery rather than inventing access.

## Knowledge taxonomy

Classify every durable item as one of:

- `CANONICAL`: authoritative contract, architecture, status, roadmap, workflow, ADR.
- `CURRENT`: short working memory, active handoff, branch/PR status.
- `EVIDENCE`: reviewed runtime/test/experiment closeout with exact identities.
- `REFERENCE`: external guide, source note, design reference.
- `HANDOFF`: context package for another chat/person/agent.
- `ARCHIVE`: superseded or historical content retained for lineage.
- `RAW`: unreviewed transcript/log/data; not a source of truth.

Use `references/knowledge-taxonomy.md`.

## Default workflow

1. Inventory available files/sources and record access limits.
2. Detect duplicates, stale versions, missing owners, missing dates, and orphaned references.
3. Create or update `WORKSPACE_KNOWLEDGE_MAP.md` with title, class, owner, currentness, source, exact ref, and replacement/supersession links.
4. Create a concise `SOURCE_OF_TRUTH.md` for the top-level canonical documents.
5. Move large histories into handoff/evidence attachments; keep shared-project instructions short.
6. Recommend what belongs in the shared Project, Library, GitHub, connected document store, or archive.
7. If explicit remote edits are requested, route writes through `github-remote-operator`.

## Attachment-first behavior

Large indexes, migration plans, or stale-document audits must be attachments. Inline output should summarize the highest-risk drift and link the files.

## Shared Project and Library guidance

Use a shared Project as the evolving collaboration hub: project instructions, a small set of current/canonical files, and team chats. Use Library or a connected document system for reusable larger files. Keep a single knowledge map linking the two. Avoid uploading many copies of the same canonical document.

Prefer filename prefixes when folders are unavailable:

```text
00_CANONICAL_
10_CURRENT_
20_EVIDENCE_
30_HANDOFF_
40_REFERENCE_
90_ARCHIVE_
```

## Self-update

On explicit request, update this skill through `workspace-skill-maintainer` and `skill-creator`, using real library-management failures as examples.
