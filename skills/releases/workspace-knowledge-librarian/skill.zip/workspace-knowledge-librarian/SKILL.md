---
name: workspace-knowledge-librarian
description: "Inspect, organize, index, deduplicate, and govern the SpireAgent knowledge plane across ChatGPT Project/Library/Work files, session scratch, GitHub governance pointers, owning repositories, and curated public-web references. Use for knowledge-library management, file lifecycle planning, storage-plane routing, stale/duplicate documents, source-of-truth maps, durable promotion, or deciding when fresh external research should be curated. Never claim Library CRUD or persistence that the active tool surface does not expose."
---

# Workspace Knowledge Librarian

## Mission

Operate Workspace knowledge as a warm human/ChatGPT collaboration layer that cooperates with a small durable Git relay and independently governed owning repositories. Keep material classified, searchable, lifecycle-aware, and explicit about authority. Respond in the user's language.

## Storage planes

Use `references/storage-planes.md` and keep four planes distinct:

- `TEMP_HOT`: current-session scratch such as `/mnt/data`; convenient but not assumed durable.
- `WORKSPACE_WARM`: ChatGPT Project/Library/Work files when the current product/tool surface actually exposes them; preferred for larger references, reusable reports, handoffs, indexes, and collaboration files.
- `GITHUB_DURABLE`: `rsgcsg/SpireAgent-Workspace`, used only for small versioned governance, pointers, shared standards, Workspace Skill releases, handoffs, knowledge maps, and selected cross-project references.
- `OWNING_REPO`: Platform/STPD implementation, runtime, evidence, research, data, model, training, and evaluation authority.

Never infer one plane's persistence, latency, access API, or authority from another.

## Product/tool boundary

A visible ChatGPT Library UI does not prove that the active agent runtime exposes generic Library list/create/move/delete operations. Inventory the capabilities actually available in the current task and state missing operations explicitly.

## Knowledge workflow

1. Inventory accessible planes, files, connectors, and read/write capabilities.
2. Classify durable items with `references/knowledge-taxonomy.md`.
3. Detect stale copies, duplicate sources, missing owners/dates, orphaned pointers, and wrong-plane storage.
4. Keep one knowledge map that points to canonical material instead of mirroring repositories or whole Libraries into Git.
5. Promote scratch intentionally: TEMP -> reviewed Workspace reference or a small durable Git pointer/reference.
6. For SpireAgent project facts, refresh exact Platform/STPD refs before promoting a summary.
7. Route explicit GitHub writes through `github-remote-operator`.
8. If a requested target is unavailable, create only the artifact the current surface supports and report the exact promotion step still required.

## Public-web knowledge lifecycle

Use `references/web-source-lifecycle.md` when current external knowledge matters.

Default order:

1. exact owning-repo evidence for project facts;
2. recent curated Workspace/Library/Git references for repeated public knowledge;
3. bounded public-web research for freshness, unresolved gaps, upstream behavior, standards/advisories, or mature ecosystem options.

Prefer official/primary sources, start with a small targeted query set, and stop once the decision is adequately supported. Reusable findings should be curated back into Workspace or a small durable reference so later agents do not repeat the same broad search. Web findings never override owning-repo truth.

## Promotion rules

- Large reusable reference/report -> `WORKSPACE_WARM` when available.
- Small versioned cross-project conclusion/pointer -> `GITHUB_DURABLE`.
- Source/runtime/research truth -> `OWNING_REPO`.
- Temporary transforms/packages -> `TEMP_HOT` until explicitly promoted.

Use stable names for current indexes and dated/versioned names for evidence/history. Archive or supersede lineage-sensitive material rather than silently overwriting it.

## Self-update

On explicit request, use `workspace-skill-maintainer` plus built-in `skill-creator`. The working Project chat should audit and prepare the change; the reliable default product path is `Plugins -> Skills -> Create -> Create with chat`, where the dedicated Skill Chat updates the existing Skill and completes native save/install. Do not create a duplicate.
