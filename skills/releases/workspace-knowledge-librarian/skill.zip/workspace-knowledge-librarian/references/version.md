Version: 1.1.1
Updated: 2026-08-28
Scope: generic shared Project/Library/connector/source-of-truth governance while deferring SpireAgent semantics to project-specific authority.
