Version: 1.4.0
Updated: 2026-08-28
Scope: four-plane Workspace/Library/Git/owning-repo lifecycle, explicit Library UI versus agent-API boundary, bounded public-web research, and durable curation of reusable external knowledge.
