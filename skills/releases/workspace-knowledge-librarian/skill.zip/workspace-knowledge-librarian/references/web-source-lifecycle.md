# Public-web source lifecycle

## When to browse

Use bounded public-web research when the task materially depends on a current external fact that repository and curated Workspace references do not reliably settle, including:

- current ChatGPT/Codex/Skills/Plugins behavior;
- current API/SDK/dependency documentation or breaking changes;
- upstream compatibility and security advisories;
- public standards;
- mature public tools or established engineering patterns worth comparing.

Do not browse merely because the web exists. Stable project facts come from owning repositories.

## Research budget

1. State the concrete external question.
2. Start with a small targeted query set.
3. Prefer official or primary sources.
4. Expand only for a real gap, contradiction, or necessary comparison.
5. Stop when the engineering decision is adequately supported.

## Curate reusable results

Promote durable findings only after review:

- large or frequently reused source packet -> Workspace/Library reference;
- concise versioned cross-project rule/pointer -> `SpireAgent-Workspace`;
- project-specific implementation/research conclusion -> owning repository.

Record source date/freshness and re-verification conditions for time-sensitive material. Web findings remain references, not Platform/STPD implementation authority.
