# Knowledge taxonomy

Each item should record:

- title and filename;
- class;
- owner;
- created/updated date;
- source system;
- exact Git ref or evidence identity when relevant;
- canonical replacement/supersession link;
- sensitivity/retention note;
- consumers.

Never promote RAW conversation/log content directly to CANONICAL. Review and summarize first.
