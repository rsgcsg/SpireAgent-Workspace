# Storage planes and lifecycle

## TEMP_HOT

Use for intermediate transforms, temporary downloads, generated packages, scratch reports, and benchmarks. `/mnt/data` belongs here unless the current product explicitly promotes a file to a durable object. Do not cite it as a durable knowledge base.

## WORKSPACE_WARM

Use ChatGPT Project/Library/Work files for persistent human/ChatGPT collaboration when direct access is actually available. Suitable for large references, design notes, handoffs, knowledge indexes, and reusable reports. Record owner, date, class, and durable source/pointer when useful.

A visible Library UI is a product fact, not proof of a generic agent CRUD API. If the current tool surface does not expose inventory/create/update/move/delete, mark those operations unavailable.

## GITHUB_DURABLE

Use `rsgcsg/SpireAgent-Workspace` as a small versioned Codex-facing relay for router/governance, CURRENT pointers, source-of-truth maps, shared standards, Workspace Skill releases/manifest, handoffs, knowledge maps, and selected durable references. Do not mirror the entire Library, chat history, Platform/STPD source, raw evidence, datasets, weights, or large mutable reports into this repository.

## OWNING_REPO

Use `rsgcsg/STS2-AI-PLATFORM` for Platform implementation/contracts/runtime/evidence and `rsgcsg/STS2-The-Perfect-Defect` for STPD research/data/model/training/evaluation. Owning repositories override Workspace caches and summaries for project truth.

## Performance checks

Benchmark only the exact plane actually exposed by tools. Report sequential throughput and small-file/request latency separately. Never use TEMP_HOT filesystem throughput as a proxy for Library or GitHub. If a plane has no direct API in the active surface, mark it `UNMEASURED`.
