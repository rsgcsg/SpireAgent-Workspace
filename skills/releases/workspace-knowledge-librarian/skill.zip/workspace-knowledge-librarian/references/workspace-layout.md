# Recommended workspace layout

## Shared Project

Keep:

- concise project instructions;
- current knowledge map;
- current handoff;
- canonical status/roadmap links or small copies;
- active decision records;
- team chats.

## Library or connected document store

Keep:

- reusable reference documents;
- long evidence reports;
- architecture studies;
- approved templates;
- historical handoffs.

## GitHub

Keep:

- canonical engineering docs;
- versioned contracts/schemas;
- reviewed evidence summaries;
- ADRs and document maps.

Do not store raw runtime data, secrets, proprietary binaries, or mutable local state merely for convenience.
