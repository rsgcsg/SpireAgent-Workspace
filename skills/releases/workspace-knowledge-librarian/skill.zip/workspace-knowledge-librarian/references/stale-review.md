# Stale review

Flag:

- multiple files claiming to be current;
- old branch/SHA in a current document;
- evidence without exact source/artifact/runtime identity;
- conversation summaries presented as canonical;
- active docs that link archived paths;
- missing owner/date/replacement;
- files duplicated in Project, Library, and GitHub with no authority rule.

Recommend deletion only when retention and ownership are clear; otherwise archive and link the replacement.
